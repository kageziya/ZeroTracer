#!/usr/bin/env python3
# ZeroTracer - децентрализованный мессенджер для Termux
# Версия 2.8: исправление уязвимостей:
#   - retransmit_count в БД (защита от бесконечной ретрансляции)
#   - глобальный rate limiter для Tor
#   - очистка старых fragment_masks
#   - дополнительные проверки фрагментов

import os
import sys
import json
import asyncio
import sqlite3
import hashlib
import base64
import subprocess
import tempfile
import shutil
import logging
import secrets
import time
import uuid
import socket as std_socket
import hmac
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any, Set
from dataclasses import dataclass, asdict
from urllib.parse import quote, unquote

# Криптография
from cryptography.hazmat.primitives.asymmetric import x25519, ed25519
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.constant_time import bytes_eq
from cryptography.hazmat.primitives.kdf.argon2 import Argon2id

# Tor SOCKS (асинхронный)
try:
    import aiosocks as aio_socks
    AIO_SOCKS_AVAILABLE = True
except ImportError:
    AIO_SOCKS_AVAILABLE = False

# QR-код (опционально)
try:
    import qrcode
    QRCODE_AVAILABLE = True
except ImportError:
    QRCODE_AVAILABLE = False

# Termux API (опционально)
TERMUX_AVAILABLE = shutil.which("termux-notification") is not None

# Argon2 (должен быть доступен)
try:
    from cryptography.hazmat.primitives.kdf.argon2 import Argon2id
    ARGON2_AVAILABLE = True
except ImportError:
    ARGON2_AVAILABLE = False
    print("Ошибка: требуется поддержка Argon2 в cryptography. Установите: pip install cryptography>=3.4")
    sys.exit(1)

# Настройка логирования
LOG_DIR = Path.home() / ".zerotracer"
LOG_DIR.mkdir(exist_ok=True)

file_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
console_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')

file_handler = logging.FileHandler(LOG_DIR / "zerotracer.log")
file_handler.setLevel(logging.DEBUG)
file_handler.setFormatter(file_formatter)

console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(console_formatter)

logger = logging.getLogger("ZeroTracer")
logger.setLevel(logging.DEBUG)
logger.addHandler(file_handler)
logger.addHandler(console_handler)

# ANSI-цвета
C_RESET = "\033[0m"
C_RED = "\033[1;31m"
C_GREEN = "\033[1;32m"
C_YELLOW = "\033[1;33m"
C_BLUE = "\033[1;34m"
C_MAGENTA = "\033[1;35m"
C_CYAN = "\033[1;36m"
C_GRAY = "\033[1;30m"

BANNER = f"""
{C_RED}╔══════════════════════════════════════════════════════════╗
{C_RED}║{C_CYAN}                                                          ║
{C_RED}║{C_CYAN}     ███████╗███████╗████████╗██████╗  █████╗  {C_RED}           ║
{C_RED}║{C_CYAN}     ╚══███╔╝██╔════╝╚══██╔══╝██╔══██╗██╔══██╗ {C_RED}           ║
{C_RED}║{C_CYAN}       ███╔╝ █████╗     ██║   ██████╔╝███████║ {C_RED}           ║
{C_RED}║{C_CYAN}      ███╔╝  ██╔══╝     ██║   ██╔══██╗██╔══██╗ {C_RED}           ║
{C_RED}║{C_CYAN}     ███████╗███████╗   ██║   ██║  ██║██║  ██║ {C_RED}           ║
{C_RED}║{C_CYAN}     ╚══════╝╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ {C_RED}           ║
{C_RED}║{C_GREEN}                ZeroTracer Messenger v2.8               {C_RED}║
{C_RED}║{C_GRAY}  E2EE | подписи | PFS | replay-защита | группы | QR     {C_RED}║
{C_RED}╚══════════════════════════════════════════════════════════╝{C_RESET}
"""

# ----------------------------------------------------------------------
# Модели данных (dataclasses)
# ----------------------------------------------------------------------
@dataclass
class Contact:
    nick: str
    addr: str               # nick@host:port
    pubkey: str             # base64 публичного ключа ed25519 (для проверки подписи)
    x25519_pub: str         # base64 публичного ключа x25519 (для DH)
    online: bool = False
    last_seen: float = 0.0
    shared_secret: Optional[bytes] = None  # вычисляется при отправке/получении

@dataclass
class Message:
    msg_id: int
    remote_addr: str
    direction: str          # 'out' или 'in' или 'group'
    text: str
    timestamp: float
    delivered: bool = False
    read: bool = False
    msg_hash: str = ""

@dataclass
class Fragment:
    msg_id: str             # уникальный идентификатор сообщения (UUID)
    from_addr: str
    part_num: int
    total_parts: int
    data: str               # зашифрованная часть
    timestamp: float

@dataclass
class Group:
    group_id: str           # уникальный идентификатор группы
    name: str
    creator: str            # адрес создателя
    symmetric_key_enc: str  # зашифрованный base64 симметричного ключа AES-256 (хранится в БД)
    members: List[str]      # список адресов участников
    created_at: float
    symmetric_key: Optional[bytes] = None
    send_counter: int = 0
    recv_counter: int = 0

# ----------------------------------------------------------------------
# Криптоменеджер (генерация ключей, подписи, общие секреты, шифрование)
# ----------------------------------------------------------------------
class CryptoManager:
    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.private_key_ed25519: Optional[ed25519.Ed25519PrivateKey] = None
        self.public_key_ed25519: Optional[ed25519.Ed25519PublicKey] = None
        self.private_key_x25519: Optional[x25519.X25519PrivateKey] = None
        self.public_key_x25519: Optional[x25519.X25519PublicKey] = None
        self.password_hash: Optional[str] = None
        self.salt: Optional[bytes] = None
        self.db_encryption_key: Optional[bytes] = None

    @staticmethod
    def _create_argon2id(salt: bytes, memory_cost=65536, iterations=3, lanes=2, length=32):
        try:
            return Argon2id(
                salt=salt,
                length=length,
                iterations=iterations,
                lanes=lanes,
                memory_cost=memory_cost,
                ad=None,
                secret=None
            )
        except TypeError as e:
            raise RuntimeError(f"Не удалось создать Argon2id: {e}")

    def generate_keys(self) -> Tuple[str, str, str, str]:
        ed_priv = ed25519.Ed25519PrivateKey.generate()
        ed_pub = ed_priv.public_key()
        x_priv = x25519.X25519PrivateKey.generate()
        x_pub = x_priv.public_key()

        ed_priv_b64 = base64.b64encode(ed_priv.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption()
        )).decode()
        ed_pub_b64 = base64.b64encode(ed_pub.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )).decode()
        x_priv_b64 = base64.b64encode(x_priv.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption()
        )).decode()
        x_pub_b64 = base64.b64encode(x_pub.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )).decode()
        return ed_pub_b64, ed_priv_b64, x_pub_b64, x_priv_b64

    def derive_db_key(self, password: str, salt: bytes) -> bytes:
        kdf = self._create_argon2id(salt=salt, memory_cost=65536, iterations=3, lanes=2, length=32)
        return kdf.derive(password.encode())

    def load_or_create_keys(self, password: str) -> bool:
        key_file = self.data_dir / "keys.enc"
        if key_file.exists():
            with open(key_file, "rb") as f:
                salt = f.read(16)
                nonce = f.read(12)
                tag = f.read(16)
                encrypted = f.read()
            try:
                kdf = self._create_argon2id(salt=salt, memory_cost=65536, iterations=3, lanes=2, length=32)
                db_key = kdf.derive(password.encode())
            except Exception as e:
                logger.error(f"Ошибка деривации ключа: {e}")
                return False
            try:
                cipher = AESGCM(db_key)
                decrypted = cipher.decrypt(nonce, encrypted + tag, None)
                parts = decrypted.decode().split('|')
                if len(parts) != 4:
                    raise ValueError("Invalid key file format")
                ed_priv_b64, ed_pub_b64, x_priv_b64, x_pub_b64 = parts
                self.private_key_ed25519 = ed25519.Ed25519PrivateKey.from_private_bytes(base64.b64decode(ed_priv_b64))
                self.public_key_ed25519 = self.private_key_ed25519.public_key()
                self.private_key_x25519 = x25519.X25519PrivateKey.from_private_bytes(base64.b64decode(x_priv_b64))
                self.public_key_x25519 = self.private_key_x25519.public_key()
                self.db_encryption_key = db_key
                logger.info("Ключи загружены из файла")
                return True
            except Exception as e:
                logger.error(f"Ошибка расшифровки ключей: {e}")
                return False
        else:
            ed_pub, ed_priv, x_pub, x_priv = self.generate_keys()
            self.private_key_ed25519 = ed25519.Ed25519PrivateKey.from_private_bytes(base64.b64decode(ed_priv))
            self.public_key_ed25519 = self.private_key_ed25519.public_key()
            self.private_key_x25519 = x25519.X25519PrivateKey.from_private_bytes(base64.b64decode(x_priv))
            self.public_key_x25519 = self.private_key_x25519.public_key()

            salt = os.urandom(16)
            db_key = self.derive_db_key(password, salt)
            self.db_encryption_key = db_key
            plain = f"{ed_priv}|{ed_pub}|{x_priv}|{x_pub}".encode()
            nonce = os.urandom(12)
            cipher = AESGCM(db_key)
            encrypted = cipher.encrypt(nonce, plain, None)
            with open(key_file, "wb") as f:
                f.write(salt)
                f.write(nonce)
                f.write(encrypted[-16:])
                f.write(encrypted[:-16])
            logger.info("Новые ключи сгенерированы и сохранены")
            return True

    def rotate_x25519_key(self) -> bool:
        key_file = self.data_dir / "keys.enc"
        if not key_file.exists():
            return False
        with open(key_file, "rb") as f:
            salt = f.read(16)
            nonce = f.read(12)
            tag = f.read(16)
            encrypted = f.read()
        if not self.db_encryption_key:
            logger.error("Нет ключа шифрования БД")
            return False
        try:
            cipher = AESGCM(self.db_encryption_key)
            decrypted = cipher.decrypt(nonce, encrypted + tag, None)
            parts = decrypted.decode().split('|')
            if len(parts) != 4:
                return False
            ed_priv_b64, ed_pub_b64, _, _ = parts
            new_x_priv = x25519.X25519PrivateKey.generate()
            new_x_pub = new_x_priv.public_key()
            new_x_priv_b64 = base64.b64encode(new_x_priv.private_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PrivateFormat.Raw,
                encryption_algorithm=serialization.NoEncryption()
            )).decode()
            new_x_pub_b64 = base64.b64encode(new_x_pub.public_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PublicFormat.Raw
            )).decode()
            self.private_key_x25519 = new_x_priv
            self.public_key_x25519 = new_x_pub
            plain = f"{ed_priv_b64}|{ed_pub_b64}|{new_x_priv_b64}|{new_x_pub_b64}".encode()
            new_nonce = os.urandom(12)
            new_encrypted = cipher.encrypt(new_nonce, plain, None)
            with open(key_file, "wb") as f:
                f.write(salt)
                f.write(new_nonce)
                f.write(new_encrypted[-16:])
                f.write(new_encrypted[:-16])
            logger.info("X25519 ключ успешно сменён (PFS)")
            return True
        except Exception as e:
            logger.error(f"Ошибка ротации X25519: {e}")
            return False

    def sign(self, data: bytes) -> bytes:
        return self.private_key_ed25519.sign(data)

    def verify(self, signature: bytes, data: bytes, pubkey_b64: str) -> bool:
        try:
            pubkey = ed25519.Ed25519PublicKey.from_public_bytes(base64.b64decode(pubkey_b64))
            pubkey.verify(signature, data)
            return True
        except InvalidSignature:
            return False

    def compute_shared_secret(self, peer_x25519_pub_b64: str) -> bytes:
        peer_pub = x25519.X25519PublicKey.from_public_bytes(base64.b64decode(peer_x25519_pub_b64))
        shared = self.private_key_x25519.exchange(peer_pub)
        hkdf = HKDF(
            algorithm=hashes.SHA256(),
            length=32,
            salt=None,
            info=b"zerotracer-messaging",
        )
        return hkdf.derive(shared)

    def encrypt_message(self, plaintext: str, shared_secret: bytes, associated_data: bytes = None) -> Tuple[str, bytes, bytes]:
        nonce = os.urandom(12)
        cipher = AESGCM(shared_secret)
        encrypted = cipher.encrypt(nonce, plaintext.encode(), associated_data)
        tag = encrypted[-16:]
        ciphertext = encrypted[:-16]
        return base64.b64encode(ciphertext).decode(), nonce, tag

    def decrypt_message(self, ciphertext_b64: str, nonce: bytes, tag: bytes, shared_secret: bytes, associated_data: bytes = None) -> str:
        ciphertext = base64.b64decode(ciphertext_b64)
        cipher = AESGCM(shared_secret)
        try:
            plain = cipher.decrypt(nonce, ciphertext + tag, associated_data)
            return plain.decode()
        except Exception as e:
            logger.error(f"Decryption error: {e}")
            return "[Ошибка дешифрования]"

    def encrypt_db_field(self, plaintext: str) -> Tuple[bytes, bytes]:
        if not self.db_encryption_key:
            return b'', plaintext.encode()
        nonce = os.urandom(12)
        cipher = AESGCM(self.db_encryption_key)
        encrypted = cipher.encrypt(nonce, plaintext.encode(), None)
        return nonce, encrypted

    def decrypt_db_field(self, nonce: bytes, encrypted_data: bytes) -> str:
        if not self.db_encryption_key or not nonce:
            return encrypted_data.decode() if isinstance(encrypted_data, bytes) else str(encrypted_data)
        cipher = AESGCM(self.db_encryption_key)
        try:
            plain = cipher.decrypt(nonce, encrypted_data, None)
            return plain.decode()
        except Exception as e:
            logger.error(f"DB decrypt error: {e}")
            return "[Ошибка расшифровки БД]"

    def encrypt_for_recipient(self, plaintext: bytes, recipient_x25519_pub_b64: str) -> bytes:
        secret = self.compute_shared_secret(recipient_x25519_pub_b64)
        nonce = os.urandom(12)
        cipher = AESGCM(secret)
        encrypted = cipher.encrypt(nonce, plaintext, None)
        return nonce + encrypted

    def decrypt_from_sender(self, encrypted_data: bytes, sender_x25519_pub_b64: str) -> bytes:
        if len(encrypted_data) < 12:
            raise ValueError("Зашифрованные данные слишком короткие")
        nonce = encrypted_data[:12]
        ciphertext_tag = encrypted_data[12:]
        secret = self.compute_shared_secret(sender_x25519_pub_b64)
        cipher = AESGCM(secret)
        return cipher.decrypt(nonce, ciphertext_tag, None)

    async def async_urandom(self, size: int) -> bytes:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, os.urandom, size)

# ----------------------------------------------------------------------
# Менеджер контактов
# ----------------------------------------------------------------------
class ContactManager:
    def __init__(self, crypto: CryptoManager, db_conn: sqlite3.Connection):
        self.crypto = crypto
        self.db_conn = db_conn
        self.contacts: List[Contact] = []
        self._init_table()
        self._load_contacts()

    def _init_table(self):
        cursor = self.db_conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS contacts (
                nick TEXT,
                addr TEXT PRIMARY KEY,
                pubkey TEXT,
                x25519_pub TEXT,
                online BOOLEAN,
                last_seen REAL,
                shared_secret BLOB
            )
        ''')
        self.db_conn.commit()

    def _load_contacts(self):
        cursor = self.db_conn.cursor()
        cursor.execute('SELECT nick, addr, pubkey, x25519_pub, online, last_seen, shared_secret FROM contacts')
        for row in cursor.fetchall():
            contact = Contact(
                nick=row[0], addr=row[1], pubkey=row[2], x25519_pub=row[3],
                online=bool(row[4]), last_seen=row[5],
                shared_secret=row[6] if row[6] else None
            )
            self.contacts.append(contact)

    def save_contact(self, contact: Contact):
        cursor = self.db_conn.cursor()
        cursor.execute('''
            INSERT OR REPLACE INTO contacts (nick, addr, pubkey, x25519_pub, online, last_seen, shared_secret)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (contact.nick, contact.addr, contact.pubkey, contact.x25519_pub,
              contact.online, contact.last_seen, contact.shared_secret))
        self.db_conn.commit()
        for i, c in enumerate(self.contacts):
            if c.addr == contact.addr:
                self.contacts[i] = contact
                return
        self.contacts.append(contact)

    def delete_contact(self, addr: str):
        cursor = self.db_conn.cursor()
        cursor.execute('DELETE FROM contacts WHERE addr=?', (addr,))
        self.db_conn.commit()
        self.contacts = [c for c in self.contacts if c.addr != addr]

    def get_contact_by_addr(self, addr: str) -> Optional[Contact]:
        for c in self.contacts:
            if c.addr == addr:
                return c
        return None

    def update_x25519_key(self, addr: str, new_x25519_pub: str):
        contact = self.get_contact_by_addr(addr)
        if contact:
            contact.x25519_pub = new_x25519_pub
            contact.shared_secret = None
            self.save_contact(contact)
            logger.info(f"Обновлён X25519 ключ для {addr}")

    def compute_shared_secret(self, contact: Contact) -> bytes:
        if contact.shared_secret is None:
            secret = self.crypto.compute_shared_secret(contact.x25519_pub)
            contact.shared_secret = secret
            self.save_contact(contact)
        return contact.shared_secret

    def add_contact_interactive(self, addr_str: str, pubkey_b64: str, x25519_pub_b64: str):
        try:
            if '@' not in addr_str:
                raise ValueError("Адрес должен содержать '@'")
            nick, rest = addr_str.split('@', 1)
            if ':' in rest:
                host, port_str = rest.rsplit(':', 1)
                port = int(port_str)
                if not (1 <= port <= 65535):
                    raise ValueError("Порт вне диапазона")
            else:
                host = rest
                port = 80
            if not nick or not host:
                raise ValueError("Ник или хост пусты")
            if host.lower() in ('localhost', '127.0.0.1', '0.0.0.0', '::1'):
                raise ValueError("Локальные адреса запрещены по соображениям безопасности")
            full_addr = f"{nick}@{host}:{port}"
        except Exception as e:
            raise ValueError(f"Неверный формат адреса: {e}")

        fingerprint = hashlib.sha256(base64.b64decode(pubkey_b64)).hexdigest()[:8]
        print(f"{C_YELLOW}Добавление контакта {nick} ({full_addr}){C_RESET}")
        print(f"{C_YELLOW}Fingerprint (Ed25519): {fingerprint}{C_RESET}")
        confirm = input("Подтвердите fingerprint (введите 'yes' для добавления): ").strip().lower()
        if confirm != 'yes':
            print("Отменено.")
            return

        contact = Contact(
            nick=nick, addr=full_addr,
            pubkey=pubkey_b64, x25519_pub=x25519_pub_b64,
            online=False, last_seen=0.0, shared_secret=None
        )
        self.save_contact(contact)
        print(f"{C_GREEN}Контакт добавлен.{C_RESET}")

    def add_contact_from_url(self, url: str):
        try:
            if url.startswith("zerotracer:add?"):
                query = url[len("zerotracer:add?"):]
                params = {}
                for pair in query.split('&'):
                    if '=' in pair:
                        k, v = pair.split('=', 1)
                        params[k] = unquote(v)
                nick = params.get('nick', '')
                addr = params.get('addr', '')
                pubkey = params.get('pubkey', '')
                x25519_pub = params.get('x25519', '')
                if not all([nick, addr, pubkey, x25519_pub]):
                    raise ValueError("Неполные параметры")
                self.add_contact_interactive(addr, pubkey, x25519_pub)
            else:
                raise ValueError("Неверный формат URL")
        except Exception as e:
            print(f"{C_RED}Ошибка разбора URL: {e}{C_RESET}")

    def set_online(self, addr: str, online: bool):
        contact = self.get_contact_by_addr(addr)
        if contact:
            contact.online = online
            contact.last_seen = time.time()
            self.save_contact(contact)

# ----------------------------------------------------------------------
# Менеджер групп
# ----------------------------------------------------------------------
class GroupManager:
    MAX_QUEUE_ATTEMPTS = 10

    def __init__(self, crypto: CryptoManager, db_conn: sqlite3.Connection):
        self.crypto = crypto
        self.db_conn = db_conn
        self.groups: Dict[str, Group] = {}
        self.group_locks: Dict[str, asyncio.Lock] = {}
        self._init_tables()
        self._load_groups()

    def _init_tables(self):
        cursor = self.db_conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS groups_info (
                group_id TEXT PRIMARY KEY,
                name TEXT,
                creator TEXT,
                symmetric_key_enc BLOB,
                members TEXT,
                created_at REAL,
                send_counter INTEGER DEFAULT 0,
                recv_counter INTEGER DEFAULT 0
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS group_nonces (
                group_id TEXT,
                nonce_hash TEXT,
                timestamp REAL,
                PRIMARY KEY (group_id, nonce_hash)
            )
        ''')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_group_nonces_ts ON group_nonces(timestamp)')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS control_nonces (
                nonce_hash TEXT PRIMARY KEY,
                timestamp REAL
            )
        ''')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_control_nonces_ts ON control_nonces(timestamp)')
        # Таблица для счётчиков ретрансляций фрагментов (защита от бесконечного цикла)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS fragment_retransmit (
                msg_id TEXT PRIMARY KEY,
                count INTEGER DEFAULT 0,
                last_update REAL
            )
        ''')
        self.db_conn.commit()

    def _hmac_nonce(self, nonce: str) -> str:
        if not self.crypto.db_encryption_key:
            return hashlib.sha256(nonce.encode()).hexdigest()
        h = hmac.new(self.crypto.db_encryption_key, nonce.encode(), hashlib.sha256)
        return h.hexdigest()

    def _load_groups(self):
        cursor = self.db_conn.cursor()
        cursor.execute('SELECT group_id, name, creator, symmetric_key_enc, members, created_at, send_counter, recv_counter FROM groups_info')
        for row in cursor.fetchall():
            members = json.loads(row[4]) if row[4] else []
            group = Group(
                group_id=row[0], name=row[1], creator=row[2],
                symmetric_key_enc=row[3], members=members, created_at=row[5],
                send_counter=row[6] or 0, recv_counter=row[7] or 0
            )
            if self.crypto.db_encryption_key and row[3]:
                try:
                    nonce = row[3][:12]
                    encrypted = row[3][12:]
                    cipher = AESGCM(self.crypto.db_encryption_key)
                    group.symmetric_key = cipher.decrypt(nonce, encrypted, None)
                except Exception as e:
                    logger.error(f"Ошибка расшифровки ключа группы {group.group_id}: {e}")
                    group.symmetric_key = None
            else:
                group.symmetric_key = None
            self.groups[row[0]] = group
            self.group_locks[row[0]] = asyncio.Lock()

    def save_group(self, group: Group):
        if group.symmetric_key:
            nonce = os.urandom(12)
            cipher = AESGCM(self.crypto.db_encryption_key)
            encrypted_key = cipher.encrypt(nonce, group.symmetric_key, None)
            sym_key_enc = nonce + encrypted_key
        else:
            sym_key_enc = b''
        cursor = self.db_conn.cursor()
        cursor.execute('''
            INSERT OR REPLACE INTO groups_info (group_id, name, creator, symmetric_key_enc, members, created_at, send_counter, recv_counter)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (group.group_id, group.name, group.creator, sym_key_enc,
              json.dumps(group.members), group.created_at, group.send_counter, group.recv_counter))
        self.db_conn.commit()

    def create_group(self, name: str, creator_addr: str) -> Group:
        group_id = secrets.token_hex(8)
        sym_key = os.urandom(32)
        group = Group(
            group_id=group_id, name=name, creator=creator_addr,
            symmetric_key_enc=b'', members=[creator_addr],
            created_at=time.time(), symmetric_key=sym_key,
            send_counter=0, recv_counter=0
        )
        self.save_group(group)
        self.groups[group_id] = group
        self.group_locks[group_id] = asyncio.Lock()
        logger.info(f"Группа '{name}' создана ({group_id})")
        return group

    def rotate_group_key(self, group_id: str, requester_addr: str) -> Optional[bytes]:
        group = self.groups.get(group_id)
        if not group or group.creator != requester_addr:
            logger.warning(f"Попытка смены ключа группы {group_id} не создателем {requester_addr}")
            return None
        new_key = os.urandom(32)
        group.symmetric_key = new_key
        self.save_group(group)
        logger.info(f"Ключ группы {group_id} сменён")
        return new_key

    def add_member(self, group_id: str, member_addr: str) -> bool:
        if group_id in self.groups:
            group = self.groups[group_id]
            if member_addr not in group.members:
                group.members.append(member_addr)
                self.save_group(group)
                return True
        return False

    def remove_member(self, group_id: str, member_addr: str, requester_addr: str) -> bool:
        group = self.groups.get(group_id)
        if not group or group.creator != requester_addr:
            return False
        if member_addr in group.members:
            group.members.remove(member_addr)
            self.save_group(group)
            self.rotate_group_key(group_id, requester_addr)
            return True
        return False

    def update_members(self, group_id: str, new_members: List[str], updater_addr: str) -> bool:
        group = self.groups.get(group_id)
        if not group or group.creator != updater_addr:
            return False
        group.members = new_members[:]
        self.save_group(group)
        logger.info(f"Список участников группы {group_id} обновлён: {len(new_members)} участников")
        return True

    def get_group(self, group_id: str) -> Optional[Group]:
        return self.groups.get(group_id)

    def list_groups(self) -> List[Group]:
        return list(self.groups.values())

    def is_nonce_used_in_group(self, group_id: str, nonce: str) -> bool:
        nonce_hash = self._hmac_nonce(nonce)
        cursor = self.db_conn.cursor()
        cursor.execute('SELECT 1 FROM group_nonces WHERE group_id=? AND nonce_hash=?', (group_id, nonce_hash))
        return cursor.fetchone() is not None

    def store_group_nonce(self, group_id: str, nonce: str):
        nonce_hash = self._hmac_nonce(nonce)
        cursor = self.db_conn.cursor()
        cursor.execute('INSERT INTO group_nonces (group_id, nonce_hash, timestamp) VALUES (?, ?, ?)',
                       (group_id, nonce_hash, time.time()))
        self.db_conn.commit()
        cursor.execute('DELETE FROM group_nonces WHERE timestamp < ?', (time.time() - 86400,))
        self.db_conn.commit()

    def is_control_nonce_used(self, nonce: str) -> bool:
        nonce_hash = self._hmac_nonce(nonce)
        cursor = self.db_conn.cursor()
        cursor.execute('SELECT 1 FROM control_nonces WHERE nonce_hash=?', (nonce_hash,))
        return cursor.fetchone() is not None

    def store_control_nonce(self, nonce: str):
        nonce_hash = self._hmac_nonce(nonce)
        cursor = self.db_conn.cursor()
        cursor.execute('INSERT INTO control_nonces (nonce_hash, timestamp) VALUES (?, ?)', (nonce_hash, time.time()))
        self.db_conn.commit()
        cursor.execute('DELETE FROM control_nonces WHERE timestamp < ?', (time.time() - 86400,))
        self.db_conn.commit()

    # Методы для работы с ретрансляциями (БД)
    def get_retransmit_count(self, msg_id: str) -> int:
        cursor = self.db_conn.cursor()
        cursor.execute('SELECT count FROM fragment_retransmit WHERE msg_id=?', (msg_id,))
        row = cursor.fetchone()
        if row:
            return row[0]
        return 0

    def increment_retransmit_count(self, msg_id: str) -> int:
        cursor = self.db_conn.cursor()
        cursor.execute('INSERT INTO fragment_retransmit (msg_id, count, last_update) VALUES (?, 1, ?) ON CONFLICT(msg_id) DO UPDATE SET count=count+1, last_update=?',
                       (msg_id, time.time(), time.time()))
        self.db_conn.commit()
        cursor.execute('DELETE FROM fragment_retransmit WHERE last_update < ?', (time.time() - 86400,))
        self.db_conn.commit()
        return self.get_retransmit_count(msg_id)

    def encrypt_group_key_for_recipient(self, group_key: bytes, recipient_addr: str) -> bytes:
        contact = self.get_contact_by_addr(recipient_addr)
        if not contact:
            raise ValueError(f"Неизвестный контакт {recipient_addr}")
        return self.crypto.encrypt_for_recipient(group_key, contact.x25519_pub)

    def decrypt_group_key_from_sender(self, encrypted_key: bytes, sender_addr: str) -> bytes:
        contact = self.get_contact_by_addr(sender_addr)
        if not contact:
            raise ValueError(f"Неизвестный отправитель {sender_addr}")
        return self.crypto.decrypt_from_sender(encrypted_key, contact.x25519_pub)

    def get_contact_by_addr(self, addr: str) -> Optional[Contact]:
        if hasattr(self, '_contact_manager'):
            return self._contact_manager.get_contact_by_addr(addr)
        return None

    def set_contact_manager(self, contact_manager):
        self._contact_manager = contact_manager

    async def request_group_sync(self, group: Group, requester: 'ZeroTracerAsync'):
        if group.creator == requester.my_addr:
            logger.warning("Нельзя запросить синхронизацию у самого себя")
            return
        nonce = secrets.token_hex(16)
        timestamp = int(time.time())
        sign_data = f"{Protocol.VERSION}{requester.my_addr}{group.creator}{group.group_id}{nonce}{timestamp}".encode()
        signature = requester.crypto.sign(sign_data)
        signature_b64 = base64.b64encode(signature).decode()
        payload = {
            "group_id": group.group_id,
            "nonce": nonce,
            "timestamp": timestamp,
            "signature": signature_b64
        }
        packet = Protocol.build_packet("group_sync_request", requester.my_addr, group.creator, payload)
        await requester._send_raw(group.creator, packet)
        logger.info(f"Запрос синхронизации группы {group.group_id} отправлен создателю {group.creator}")

# ----------------------------------------------------------------------
# Менеджер очереди и фрагментов (БД)
# ----------------------------------------------------------------------
class MessageStore:
    MAX_TOTAL_CIPHER_BYTES = 10 * 1024 * 1024
    MAX_FRAGMENTS = 1000
    MAX_QUEUE_ATTEMPTS = 10
    MAX_QUEUE_SIZE = 1000

    def __init__(self, db_conn: sqlite3.Connection, crypto: CryptoManager):
        self.db_conn = db_conn
        self.crypto = crypto
        self._init_tables()

    def _init_tables(self):
        cursor = self.db_conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                remote_addr TEXT,
                direction TEXT,
                text_enc BLOB,
                text_nonce BLOB,
                timestamp REAL,
                delivered BOOLEAN DEFAULT 0,
                read BOOLEAN DEFAULT 0,
                msg_hash TEXT UNIQUE,
                msg_id TEXT,
                nonce BLOB,
                tag BLOB,
                ciphertext TEXT
            )
        ''')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_messages_remote_addr ON messages(remote_addr)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_messages_timestamp ON messages(timestamp)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_messages_direction ON messages(direction)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_messages_msg_id ON messages(msg_id)')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS outgoing_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                target_addr TEXT,
                plain_enc BLOB,
                plain_nonce BLOB,
                timestamp REAL,
                attempts INTEGER DEFAULT 0,
                msg_hash TEXT,
                original_msg_id TEXT,
                is_group BOOLEAN DEFAULT 0,
                group_id TEXT
            )
        ''')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_queue_target ON outgoing_queue(target_addr)')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS fragments (
                msg_id TEXT,
                from_addr TEXT,
                part_num INTEGER,
                total_parts INTEGER,
                data TEXT,
                timestamp REAL,
                PRIMARY KEY (msg_id, part_num)
            )
        ''')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_fragments_msg_id ON fragments(msg_id)')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS used_nonces (
                nonce_hash TEXT PRIMARY KEY,
                timestamp REAL
            )
        ''')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_nonces_timestamp ON used_nonces(timestamp)')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS fragment_masks (
                msg_id TEXT,
                from_addr TEXT,
                total_parts INTEGER,
                received_mask TEXT,
                last_update REAL,
                PRIMARY KEY (msg_id, from_addr)
            )
        ''')
        cursor.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_messages_nonce ON messages(remote_addr, nonce) WHERE nonce IS NOT NULL')
        # Добавляем столбец last_update если его нет
        try:
            cursor.execute('ALTER TABLE fragment_masks ADD COLUMN last_update REAL')
        except sqlite3.OperationalError:
            pass
        self.db_conn.commit()

    def _hmac_nonce(self, nonce: str) -> str:
        if not self.crypto.db_encryption_key:
            return hashlib.sha256(nonce.encode()).hexdigest()
        h = hmac.new(self.crypto.db_encryption_key, nonce.encode(), hashlib.sha256)
        return h.hexdigest()

    def save_message(self, remote_addr: str, direction: str, text: str, msg_id: str,
                     nonce: bytes = None, tag: bytes = None, ciphertext: str = None) -> Tuple[int, str]:
        salt = secrets.token_hex(8)
        msg_hash = hashlib.sha256(f"{remote_addr}{text}{msg_id}{salt}".encode()).hexdigest()
        text_nonce, text_enc = self.crypto.encrypt_db_field(text)
        cursor = self.db_conn.cursor()
        cursor.execute('''
            INSERT INTO messages (remote_addr, direction, text_enc, text_nonce, timestamp, delivered, read, msg_hash, msg_id, nonce, tag, ciphertext)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (remote_addr, direction, text_enc, text_nonce, time.time(), False, False, msg_hash, msg_id,
              nonce, tag, ciphertext))
        self.db_conn.commit()
        return cursor.lastrowid, msg_hash

    def mark_delivered(self, db_id: int):
        cursor = self.db_conn.cursor()
        cursor.execute("UPDATE messages SET delivered=1 WHERE id=?", (db_id,))
        self.db_conn.commit()

    def mark_read(self, db_id: int):
        cursor = self.db_conn.cursor()
        cursor.execute("UPDATE messages SET read=1 WHERE id=?", (db_id,))
        self.db_conn.commit()

    def get_unread_messages(self, remote_addr: str) -> List[Tuple[int, str]]:
        cursor = self.db_conn.cursor()
        cursor.execute('''
            SELECT id, msg_id FROM messages
            WHERE remote_addr=? AND direction='in' AND read=0
        ''', (remote_addr,))
        return cursor.fetchall()

    def get_unread_messages_all(self) -> List[Tuple[int, str, str]]:
        cursor = self.db_conn.cursor()
        cursor.execute('''
            SELECT id, msg_id, remote_addr FROM messages
            WHERE direction='in' AND read=0
        ''')
        return cursor.fetchall()

    def is_message_delivered(self, msg_id: str) -> bool:
        cursor = self.db_conn.cursor()
        cursor.execute("SELECT delivered FROM messages WHERE msg_id=?", (msg_id,))
        row = cursor.fetchone()
        return row is not None and bool(row[0])

    def _encrypt_plain_for_queue(self, plain_text: str) -> Tuple[bytes, bytes]:
        nonce = os.urandom(12)
        cipher = AESGCM(self.crypto.db_encryption_key)
        encrypted = cipher.encrypt(nonce, plain_text.encode(), None)
        return nonce, encrypted

    def _decrypt_plain_from_queue(self, nonce: bytes, encrypted: bytes) -> str:
        cipher = AESGCM(self.crypto.db_encryption_key)
        try:
            plain = cipher.decrypt(nonce, encrypted, None)
            return plain.decode()
        except Exception:
            return "[Ошибка расшифровки очереди]"

    def queue_message(self, target_addr: str, plain_text: str, original_msg_id: str, msg_hash: str,
                      is_group: bool = False, group_id: str = ""):
        cursor = self.db_conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM outgoing_queue")
        count = cursor.fetchone()[0]
        if count >= self.MAX_QUEUE_SIZE:
            logger.warning(f"Очередь переполнена ({count} сообщений), сообщение не добавлено")
            return
        plain_nonce, plain_enc = self._encrypt_plain_for_queue(plain_text)
        cursor.execute('''
            INSERT INTO outgoing_queue (target_addr, plain_enc, plain_nonce, timestamp, attempts, msg_hash, original_msg_id, is_group, group_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (target_addr, plain_enc, plain_nonce, time.time(), 0, msg_hash, original_msg_id, is_group, group_id))
        self.db_conn.commit()

    def get_queued_messages(self) -> List[Tuple[int, str, str, str, str, bool, str, int]]:
        cursor = self.db_conn.cursor()
        cursor.execute('SELECT id, target_addr, plain_enc, plain_nonce, msg_hash, original_msg_id, is_group, group_id, attempts FROM outgoing_queue ORDER BY timestamp')
        rows = cursor.fetchall()
        result = []
        for row in rows:
            plain_text = self._decrypt_plain_from_queue(row[3], row[2])
            result.append((row[0], row[1], plain_text, row[4], row[5], bool(row[6]), row[7], row[8]))
        return result

    def delete_queued(self, qid: int):
        cursor = self.db_conn.cursor()
        cursor.execute('DELETE FROM outgoing_queue WHERE id=?', (qid,))
        self.db_conn.commit()

    def increment_attempts(self, qid: int) -> bool:
        cursor = self.db_conn.cursor()
        cursor.execute('UPDATE outgoing_queue SET attempts=attempts+1 WHERE id=?', (qid,))
        self.db_conn.commit()
        cursor.execute('SELECT attempts FROM outgoing_queue WHERE id=?', (qid,))
        row = cursor.fetchone()
        if row and row[0] >= self.MAX_QUEUE_ATTEMPTS:
            self.delete_queued(qid)
            logger.warning(f"Сообщение в очереди {qid} превысило лимит попыток ({self.MAX_QUEUE_ATTEMPTS}), удалено")
            return True
        return False

    def save_fragment(self, fragment: Fragment):
        cursor = self.db_conn.cursor()
        cursor.execute('''
            INSERT OR REPLACE INTO fragments (msg_id, from_addr, part_num, total_parts, data, timestamp)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (fragment.msg_id, fragment.from_addr, fragment.part_num, fragment.total_parts, fragment.data, fragment.timestamp))
        self.db_conn.commit()

    def get_fragments(self, msg_id: str, from_addr: str) -> List[Fragment]:
        cursor = self.db_conn.cursor()
        cursor.execute('SELECT msg_id, from_addr, part_num, total_parts, data, timestamp FROM fragments WHERE msg_id=? AND from_addr=? ORDER BY part_num', (msg_id, from_addr))
        rows = cursor.fetchall()
        return [Fragment(*row) for row in rows]

    def delete_fragments(self, msg_id: str, from_addr: str):
        cursor = self.db_conn.cursor()
        cursor.execute('DELETE FROM fragments WHERE msg_id=? AND from_addr=?', (msg_id, from_addr))
        self.db_conn.commit()

    def cleanup_old_fragments(self, max_age: int = 300):
        cutoff = time.time() - max_age
        cursor = self.db_conn.cursor()
        cursor.execute('DELETE FROM fragments WHERE timestamp < ?', (cutoff,))
        # Также удаляем старые маски фрагментов
        cursor.execute('DELETE FROM fragment_masks WHERE last_update < ?', (cutoff,))
        self.db_conn.commit()

    def is_nonce_used(self, nonce: str) -> bool:
        nonce_hash = self._hmac_nonce(nonce)
        cursor = self.db_conn.cursor()
        cursor.execute('SELECT 1 FROM used_nonces WHERE nonce_hash=?', (nonce_hash,))
        return cursor.fetchone() is not None

    def store_nonce(self, nonce: str):
        nonce_hash = self._hmac_nonce(nonce)
        cursor = self.db_conn.cursor()
        cursor.execute('INSERT INTO used_nonces (nonce_hash, timestamp) VALUES (?, ?)', (nonce_hash, time.time()))
        self.db_conn.commit()
        cursor.execute('DELETE FROM used_nonces WHERE timestamp < ?', (time.time() - 86400,))
        self.db_conn.commit()

    def update_fragment_mask(self, msg_id: str, from_addr: str, total_parts: int, part_num: int) -> int:
        cursor = self.db_conn.cursor()
        cursor.execute('SELECT received_mask FROM fragment_masks WHERE msg_id=? AND from_addr=?', (msg_id, from_addr))
        row = cursor.fetchone()
        if row:
            mask = int(row[0], 2) if row[0] else 0
        else:
            mask = 0
            cursor.execute('''
                INSERT INTO fragment_masks (msg_id, from_addr, total_parts, received_mask, last_update)
                VALUES (?, ?, ?, ?, ?)
            ''', (msg_id, from_addr, total_parts, '0' * total_parts, time.time()))
        mask |= (1 << (part_num - 1))
        mask_str = format(mask, f'0{total_parts}b')
        cursor.execute('UPDATE fragment_masks SET received_mask=?, last_update=? WHERE msg_id=? AND from_addr=?',
                       (mask_str, time.time(), msg_id, from_addr))
        self.db_conn.commit()
        return mask

    def get_missing_parts(self, msg_id: str, from_addr: str, total_parts: int) -> List[int]:
        cursor = self.db_conn.cursor()
        cursor.execute('SELECT received_mask FROM fragment_masks WHERE msg_id=? AND from_addr=?', (msg_id, from_addr))
        row = cursor.fetchone()
        if not row or not row[0]:
            return list(range(1, total_parts + 1))
        mask_str = row[0]
        missing = []
        for i in range(total_parts):
            if i >= len(mask_str) or mask_str[i] == '0':
                missing.append(i + 1)
        return missing

    def clear_fragment_mask(self, msg_id: str, from_addr: str):
        cursor = self.db_conn.cursor()
        cursor.execute('DELETE FROM fragment_masks WHERE msg_id=? AND from_addr=?', (msg_id, from_addr))
        self.db_conn.commit()

    def get_history(self, limit: int = 20) -> List[dict]:
        cursor = self.db_conn.cursor()
        cursor.execute('''
            SELECT id, remote_addr, direction, text_enc, text_nonce, timestamp, delivered, read, msg_hash, msg_id
            FROM messages ORDER BY timestamp DESC LIMIT ?
        ''', (limit,))
        rows = cursor.fetchall()
        result = []
        for row in rows:
            text = self.crypto.decrypt_db_field(row[4], row[3])
            result.append({
                'id': row[0], 'remote_addr': row[1], 'direction': row[2],
                'text': text, 'timestamp': row[5], 'delivered': bool(row[6]),
                'read': bool(row[7]), 'msg_hash': row[8], 'msg_id': row[9]
            })
        return result

    def cleanup_old_messages(self, days: int = 30):
        cutoff = time.time() - days * 86400
        cursor = self.db_conn.cursor()
        cursor.execute('DELETE FROM messages WHERE timestamp < ?', (cutoff,))
        self.db_conn.commit()
        logger.info(f"Очистка сообщений: удалено {cursor.rowcount} записей старше {days} дней")

# ----------------------------------------------------------------------
# Менеджер Tor
# ----------------------------------------------------------------------
class TorManager:
    def __init__(self, use_tor: bool, ports: List[int]):
        self.use_tor = use_tor
        self.ports = ports
        self.tor_process = None
        self.hs_dir = None
        self.onion_host = None
        self.tor_proxy = ("127.0.0.1", 9050) if use_tor else None
        self.running = True

    def start_hidden_service(self, first_port: int) -> Optional[str]:
        if not self.use_tor:
            return None
        if not shutil.which("tor"):
            logger.error("Команда 'tor' не найдена. Установите: pkg install tor (Termux) или apt install tor")
            self.use_tor = False
            return None
        self.hs_dir = tempfile.mkdtemp(prefix="zerotracer_hs_")
        hidden_ports = "\n".join(f"HiddenServicePort {port} 127.0.0.1:{port}" for port in self.ports)
        torrc = f"""
HiddenServiceDir {self.hs_dir}
{hidden_ports}
"""
        torrc_path = os.path.join(self.hs_dir, "torrc")
        with open(torrc_path, "w") as f:
            f.write(torrc)
        try:
            self.tor_process = subprocess.Popen(
                ["tor", "-f", torrc_path, "--runasdaemon", "0", "--CookieAuthentication", "0"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            )
            hostname_file = os.path.join(self.hs_dir, "hostname")
            for _ in range(20):
                if os.path.exists(hostname_file):
                    with open(hostname_file, "r") as f:
                        self.onion_host = f.read().strip()
                    break
                time.sleep(0.5)
            if self.onion_host:
                logger.info(f"Tor скрытый сервис создан: {self.onion_host}")
            else:
                logger.error("Не удалось получить onion-адрес")
        except Exception as e:
            logger.error(f"Ошибка запуска Tor: {e}")
            self.use_tor = False
        return self.onion_host

    def stop_hidden_service(self):
        if self.tor_process:
            self.tor_process.terminate()
            self.tor_process.wait()
        if self.hs_dir and os.path.exists(self.hs_dir):
            shutil.rmtree(self.hs_dir, ignore_errors=True)

    async def monitor_tor(self, restart_callback):
        if not self.use_tor:
            return
        while self.running:
            if self.tor_process and self.tor_process.poll() is not None:
                logger.warning("Процесс Tor упал, перезапуск...")
                self.stop_hidden_service()
                new_onion = self.start_hidden_service(self.ports[0] if self.ports else 0)
                if new_onion and restart_callback:
                    await restart_callback(new_onion)
            await asyncio.sleep(30)

# ----------------------------------------------------------------------
# Сетевой протокол
# ----------------------------------------------------------------------
class Protocol:
    VERSION = 1

    @staticmethod
    def build_packet(msg_type: str, from_addr: str, to_addr: str, payload: dict) -> str:
        packet = {
            "version": Protocol.VERSION,
            "type": msg_type,
            "from": from_addr,
            "to": to_addr,
            "payload": payload
        }
        return json.dumps(packet)

    @staticmethod
    def parse_packet(data: str) -> Optional[dict]:
        try:
            return json.loads(data)
        except:
            return None

# ----------------------------------------------------------------------
# Rate limiter (с поддержкой отдельного глобального лимита для Tor)
# ----------------------------------------------------------------------
class RateLimiter:
    def __init__(self, max_requests: int = 10, per_seconds: int = 1, max_bytes_per_sec: int = 1024 * 1024):
        self.max_requests = max_requests
        self.per_seconds = per_seconds
        self.max_bytes_per_sec = max_bytes_per_sec
        self.clients: Dict[str, List[float]] = {}
        self.bytes_received: Dict[str, Tuple[float, int]] = {}

    def is_allowed(self, client_id: str, data_len: int = 0) -> bool:
        now = time.time()
        if client_id not in self.clients:
            self.clients[client_id] = []
        self.clients[client_id] = [t for t in self.clients[client_id] if now - t < self.per_seconds]
        if len(self.clients[client_id]) >= self.max_requests:
            return False
        self.clients[client_id].append(now)

        if client_id not in self.bytes_received:
            self.bytes_received[client_id] = (now, 0)
        reset_time, total_bytes = self.bytes_received[client_id]
        if now - reset_time > self.per_seconds:
            reset_time = now
            total_bytes = 0
        total_bytes += data_len
        if total_bytes > self.max_bytes_per_sec:
            return False
        self.bytes_received[client_id] = (reset_time, total_bytes)
        return True

# ----------------------------------------------------------------------
# Асинхронный сервер и клиент
# ----------------------------------------------------------------------
class ZeroTracerAsync:
    def __init__(self, use_tor: bool = False):
        self.data_dir = Path.home() / ".zerotracer"
        self.data_dir.mkdir(exist_ok=True)
        self.db_path = self.data_dir / "messages.db"
        self.db_conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.nick = None
        self.ports = []
        self.use_tor = use_tor
        self.onion_host = None
        self.ip = "127.0.0.1"
        self.my_addr = ""
        self.running = True
        self.notifications_enabled = True
        self.rate_limiter = RateLimiter(max_requests=10, per_seconds=1, max_bytes_per_sec=1024*1024)
        # Дополнительный глобальный лимитер для Tor-соединений (защита от DoS через Tor)
        self.tor_global_limiter = RateLimiter(max_requests=50, per_seconds=1, max_bytes_per_sec=5*1024*1024)

        self.crypto = CryptoManager(self.data_dir)
        self.contact_manager = None
        self.message_store = None
        self.group_manager = None
        self.tor_manager = TorManager(use_tor, self.ports)

        self.servers = []
        self.pending_fragments: Dict[Tuple[str, str], Dict[int, str]] = {}
        self.pending_fragment_meta: Dict[Tuple[str, str], Tuple[int, str]] = {}
        self.pending_fragments_timestamp: Dict[Tuple[str, str], float] = {}
        self.processed_fragmented_msgs: Set[str] = set()
        self.semaphore = asyncio.Semaphore(100)

        self._load_config()
        self._init_crypto()
        self.contact_manager = ContactManager(self.crypto, self.db_conn)
        self.message_store = MessageStore(self.db_conn, self.crypto)
        self.group_manager = GroupManager(self.crypto, self.db_conn)
        self.group_manager.set_contact_manager(self.contact_manager)
        self._update_my_address()

        if self.use_tor and not self.onion_host:
            self.onion_host = self.tor_manager.start_hidden_service(self.ports[0] if self.ports else 0)
            self._update_my_address()

        self.on_message_callback = None
        self.on_status_change_callback = None

    def _load_config(self):
        config_file = self.data_dir / "config.json"
        if config_file.exists():
            with open(config_file) as f:
                cfg = json.load(f)
            self.nick = cfg.get("nick")
            self.ports = cfg.get("ports", [])
            self.use_tor = cfg.get("use_tor", self.use_tor)
            self.notifications_enabled = cfg.get("notifications", True)
        if not self.nick:
            self.nick = self._generate_nick()
        if not self.ports:
            self._request_ports()

    def _save_config(self):
        config_file = self.data_dir / "config.json"
        cfg = {
            "nick": self.nick,
            "ports": self.ports,
            "use_tor": self.use_tor,
            "notifications": self.notifications_enabled
        }
        with open(config_file, "w") as f:
            json.dump(cfg, f)

    def _request_ports(self):
        ports_input = input(f"{C_CYAN}Введите порты для прослушивания (через запятую, например 5555,5556): {C_RESET}")
        self.ports = [int(p.strip()) for p in ports_input.split(',') if p.strip().isdigit()]
        if not self.ports:
            self.ports = [5555]
        self._save_config()

    def _generate_nick(self, length=6):
        import random, string
        return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

    def _init_crypto(self):
        max_attempts = 3
        print(f"{C_YELLOW}Рекомендуется использовать длинный и сложный пароль (не менее 12 символов){C_RESET}")
        for attempt in range(max_attempts):
            pwd = input(f"{C_CYAN}Введите пароль для доступа к ключам и БД (попытка {attempt+1}/{max_attempts}): {C_RESET}").strip()
            if not pwd:
                print(f"{C_RED}Пароль обязателен для работы!{C_RESET}")
                continue
            if self.crypto.load_or_create_keys(pwd):
                print(f"{C_GREEN}Криптосистема инициализирована.{C_RESET}")
                return
            else:
                print(f"{C_RED}Неверный пароль или повреждённый файл ключей.{C_RESET}")
        print(f"{C_YELLOW}Исчерпаны попытки ввода пароля.{C_RESET}")
        choice = input("Создать новые ключи? (старые контакты будут потеряны) [y/N]: ").strip().lower()
        if choice == 'y':
            key_file = self.data_dir / "keys.enc"
            if key_file.exists():
                key_file.unlink()
            if self.db_path.exists():
                self.db_path.unlink()
                self.db_conn = sqlite3.connect(self.db_path, check_same_thread=False)
            self._init_crypto()
        else:
            print(f"{C_RED}Выход.{C_RESET}")
            sys.exit(1)

    def _update_my_address(self):
        old_addr = self.my_addr
        if self.use_tor and self.onion_host:
            self.my_addr = f"{self.nick}@{self.onion_host}:{self.ports[0] if self.ports else 0}"
        else:
            try:
                s = std_socket.socket(std_socket.AF_INET, std_socket.SOCK_DGRAM)
                s.settimeout(2)
                s.connect(("8.8.8.8", 80))
                self.ip = s.getsockname()[0]
                s.close()
            except:
                self.ip = "127.0.0.1"
            self.my_addr = f"{self.nick}@{self.ip}:{self.ports[0] if self.ports else 0}"
        if old_addr and old_addr != self.my_addr:
            logger.info(f"Адрес изменился: {old_addr} -> {self.my_addr}")
        logger.debug(f"Мой адрес: {self.my_addr}")

    def generate_mykey_url(self) -> str:
        ed_pub_b64 = base64.b64encode(self.crypto.public_key_ed25519.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )).decode()
        x_pub_b64 = base64.b64encode(self.crypto.public_key_x25519.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )).decode()
        params = f"nick={quote(self.nick)}&addr={quote(self.my_addr)}&pubkey={quote(ed_pub_b64)}&x25519={quote(x_pub_b64)}"
        return f"zerotracer:add?{params}"

    def send_notification(self, title: str, body: str):
        if not self.notifications_enabled or not TERMUX_AVAILABLE:
            return
        try:
            subprocess.run([
                "termux-notification",
                "--title", title,
                "--content", body,
                "--priority", "high"
            ], timeout=5, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception as e:
            logger.debug(f"Ошибка уведомления: {e}")

    async def start_servers(self):
        for port in self.ports:
            server = await asyncio.start_server(
                self._handle_client, host='127.0.0.1' if self.use_tor else '0.0.0.0', port=port
            )
            self.servers.append(server)
            logger.info(f"Сервер запущен на порту {port}")

    async def _handle_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        async with self.semaphore:
            peer_addr = writer.get_extra_info('peername')
            client_key = peer_addr[0] if peer_addr else "unknown"
            # Если используется Tor, все соединения идут с 127.0.0.1 – применяем глобальный лимитер
            if self.use_tor and client_key == "127.0.0.1":
                if not self.tor_global_limiter.is_allowed("tor_global", 0):
                    logger.warning(f"Tor глобальный лимит превышен")
                    writer.close()
                    await writer.wait_closed()
                    return
            try:
                data = await asyncio.wait_for(reader.read(1024 * 1024), timeout=30)
                if not data:
                    return
                if not self.rate_limiter.is_allowed(client_key, len(data)):
                    logger.warning(f"Rate limit exceeded for {client_key}")
                    writer.close()
                    await writer.wait_closed()
                    return
                packet_str = data.decode('utf-8')
                packet = Protocol.parse_packet(packet_str)
                if not packet:
                    logger.warning("Невалидный пакет")
                    return
                if packet.get("version") != Protocol.VERSION:
                    logger.warning(f"Неверная версия протокола: {packet.get('version')} от {client_key}")
                    return
                await self._process_packet(packet, writer)
            except asyncio.TimeoutError:
                logger.debug("Таймаут чтения от клиента")
            except Exception as e:
                logger.error(f"Ошибка обработки клиента: {e}")
            finally:
                try:
                    writer.close()
                    await writer.wait_closed()
                except:
                    pass

    async def _process_packet(self, packet: dict, writer: asyncio.StreamWriter):
        msg_type = packet.get("type")
        from_addr = packet.get("from")
        to_addr = packet.get("to")
        payload = packet.get("payload", {})

        if to_addr != self.my_addr:
            return

        if msg_type == "message":
            await self._handle_message(from_addr, payload, writer)
        elif msg_type == "ack":
            await self._handle_ack(payload)
        elif msg_type == "read_receipt":
            await self._handle_read_receipt(payload)
        elif msg_type == "fragment_ack":
            await self._handle_fragment_ack(from_addr, payload)
        elif msg_type == "fragment_retransmit":
            await self._handle_fragment_retransmit_packet(from_addr, payload, writer)
        elif msg_type == "ping":
            await self._handle_ping(from_addr, payload, writer)
        elif msg_type == "pong":
            await self._handle_pong(from_addr, payload)
        elif msg_type == "group_invite":
            await self._handle_group_invite(from_addr, payload)
        elif msg_type == "group_message":
            await self._handle_group_message(from_addr, payload)
        elif msg_type == "group_sync":
            await self._handle_group_sync(from_addr, payload)
        elif msg_type == "group_key_update":
            await self._handle_group_key_update(from_addr, payload)
        elif msg_type == "key_update":
            await self._handle_key_update(from_addr, payload)
        elif msg_type == "group_sync_request":
            await self._handle_group_sync_request(from_addr, payload)
        else:
            logger.warning(f"Неизвестный тип сообщения: {msg_type}")

    # ========================= ЛИЧНЫЕ СООБЩЕНИЯ =========================
    async def _handle_message(self, from_addr: str, payload: dict, writer: asyncio.StreamWriter):
        msg_id = payload.get("msg_id")
        signature_b64 = payload.get("signature")
        nonce_b64 = payload.get("nonce")
        tag_b64 = payload.get("tag")
        ciphertext_b64 = payload.get("ciphertext")
        whole_hash = payload.get("whole_hash")
        part_num = payload.get("part_num")
        total_parts = payload.get("total_parts")
        timestamp = payload.get("timestamp", 0)

        if timestamp and abs(time.time() - timestamp) > 60:
            logger.warning(f"Личное сообщение от {from_addr} слишком старое (timestamp {timestamp})")
            return

        if nonce_b64:
            if self.message_store.is_nonce_used(nonce_b64):
                logger.warning(f"Replay личного сообщения от {from_addr} (nonce {nonce_b64})")
                return
            self.message_store.store_nonce(nonce_b64)

        contact = self.contact_manager.get_contact_by_addr(from_addr)
        if not contact:
            logger.warning(f"Сообщение от неизвестного контакта {from_addr}")
            return

        if part_num is not None and total_parts is not None and total_parts > 1:
            if total_parts > self.message_store.MAX_FRAGMENTS:
                logger.warning(f"Слишком много фрагментов ({total_parts}) от {from_addr}")
                return
            if part_num > total_parts:
                logger.warning(f"Неверный номер фрагмента {part_num} > {total_parts}")
                return
            if msg_id in self.processed_fragmented_msgs:
                logger.debug(f"Сообщение {msg_id} уже обработано, игнорируем фрагмент")
                return

            key = (from_addr, msg_id)
            self.pending_fragments_timestamp[key] = time.time()
            if key not in self.pending_fragments:
                self.pending_fragments[key] = {}
                self.pending_fragment_meta[key] = (total_parts, whole_hash)
            self.pending_fragments[key][part_num] = ciphertext_b64
            self.message_store.update_fragment_mask(msg_id, from_addr, total_parts, part_num)
            missing = self.message_store.get_missing_parts(msg_id, from_addr, total_parts)
            if missing:
                await self._send_fragment_ack(from_addr, msg_id, missing, total_parts)
                return
            full_ciphertext = ""
            for i in range(1, total_parts+1):
                full_ciphertext += self.pending_fragments[key].get(i, "")
            if not full_ciphertext:
                logger.error("Не удалось собрать фрагменты")
                return

            if whole_hash and hashlib.sha256(full_ciphertext.encode()).hexdigest() != whole_hash:
                logger.warning(f"Хэш собранного сообщения не совпадает от {from_addr}")
                return

            ciphertext_b64 = full_ciphertext
            del self.pending_fragments[key]
            del self.pending_fragment_meta[key]
            del self.pending_fragments_timestamp[key]
            self.message_store.clear_fragment_mask(msg_id, from_addr)
            self.processed_fragmented_msgs.add(msg_id)

        sign_data = f"{Protocol.VERSION}{self.my_addr}{msg_id}{nonce_b64}{ciphertext_b64}{from_addr}".encode()
        try:
            signature = base64.b64decode(signature_b64)
        except Exception:
            logger.warning(f"Неверный base64 подписи от {from_addr}")
            return
        if not self.crypto.verify(signature, sign_data, contact.pubkey):
            logger.warning(f"Неверная подпись сообщения от {from_addr}")
            return

        shared_secret = self.contact_manager.compute_shared_secret(contact)
        try:
            nonce = base64.b64decode(nonce_b64)
            tag = base64.b64decode(tag_b64)
            associated_data = f"{msg_id}{from_addr}{self.my_addr}".encode()
            plain = self.crypto.decrypt_message(ciphertext_b64, nonce, tag, shared_secret, associated_data)
        except Exception as e:
            logger.error(f"Ошибка расшифровки личного сообщения: {e}")
            return

        db_id, msg_hash = self.message_store.save_message(from_addr, "in", plain, msg_id)
        logger.info(f"Личное сообщение от {from_addr}: {plain[:50]}")
        self.send_notification(f"ZeroTracer: {contact.nick}", plain[:100])

        await self._send_ack(from_addr, msg_id)
        await self._send_read_receipt(from_addr, msg_id)
        self.message_store.mark_read(db_id)

        if self.on_message_callback:
            await self.on_message_callback(from_addr, plain)

    async def _send_ack(self, to_addr: str, msg_id: str):
        payload = {"msg_id": msg_id}
        packet = Protocol.build_packet("ack", self.my_addr, to_addr, payload)
        await self._send_raw(to_addr, packet)

    async def _send_read_receipt(self, to_addr: str, msg_id: str):
        payload = {"msg_id": msg_id}
        packet = Protocol.build_packet("read_receipt", self.my_addr, to_addr, payload)
        await self._send_raw(to_addr, packet)

    async def _handle_ack(self, payload: dict):
        msg_id = payload.get("msg_id")
        cursor = self.message_store.db_conn.cursor()
        cursor.execute("UPDATE messages SET delivered=1 WHERE msg_id=?", (msg_id,))
        self.message_store.db_conn.commit()
        logger.debug(f"ACK для сообщения {msg_id}")

    async def _handle_read_receipt(self, payload: dict):
        msg_id = payload.get("msg_id")
        cursor = self.message_store.db_conn.cursor()
        cursor.execute("UPDATE messages SET read=1 WHERE msg_id=?", (msg_id,))
        self.message_store.db_conn.commit()
        logger.debug(f"Read receipt для сообщения {msg_id}")

    async def _send_fragment_ack(self, to_addr: str, msg_id: str, missing_parts: List[int], total_parts: int):
        nonce = secrets.token_hex(16)
        timestamp = int(time.time())
        sign_data = f"{Protocol.VERSION}{self.my_addr}{to_addr}{msg_id}{json.dumps(missing_parts)}{total_parts}{nonce}{timestamp}".encode()
        signature = self.crypto.sign(sign_data)
        signature_b64 = base64.b64encode(signature).decode()
        payload = {
            "msg_id": msg_id,
            "missing_parts": missing_parts,
            "total_parts": total_parts,
            "nonce": nonce,
            "timestamp": timestamp,
            "signature": signature_b64
        }
        packet = Protocol.build_packet("fragment_ack", self.my_addr, to_addr, payload)
        await self._send_raw(to_addr, packet)

    async def _handle_fragment_ack(self, from_addr: str, payload: dict):
        msg_id = payload.get("msg_id")
        missing_parts = payload.get("missing_parts", [])
        total_parts = payload.get("total_parts", 0)
        nonce = payload.get("nonce")
        timestamp = payload.get("timestamp", 0)
        signature_b64 = payload.get("signature")

        if not nonce or not timestamp or not signature_b64:
            logger.warning(f"fragment_ack от {from_addr} без nonce/timestamp/подписи")
            return
        current_time = time.time()
        if abs(current_time - timestamp) > 60:
            logger.warning(f"fragment_ack от {from_addr} слишком старый")
            return
        if self.group_manager.is_control_nonce_used(nonce):
            logger.warning(f"Replay fragment_ack от {from_addr}")
            return
        self.group_manager.store_control_nonce(nonce)

        contact = self.contact_manager.get_contact_by_addr(from_addr)
        if not contact:
            logger.warning(f"fragment_ack от неизвестного {from_addr}")
            return
        sign_data = f"{Protocol.VERSION}{self.my_addr}{from_addr}{msg_id}{json.dumps(missing_parts)}{total_parts}{nonce}{timestamp}".encode()
        try:
            signature = base64.b64decode(signature_b64)
        except:
            logger.warning(f"Неверный base64 подписи fragment_ack от {from_addr}")
            return
        if not self.crypto.verify(signature, sign_data, contact.pubkey):
            logger.warning(f"Неверная подпись fragment_ack от {from_addr}")
            return

        if not missing_parts:
            logger.debug(f"Все фрагменты {msg_id} получены адресатом")
            return

        # Используем БД для счётчика ретрансляций (защита от бесконечного цикла)
        retransmit_count = self.group_manager.get_retransmit_count(msg_id)
        if retransmit_count >= 3:
            logger.warning(f"Превышено количество ретрансляций для {msg_id} (БД), игнорируем fragment_ack")
            return
        self.group_manager.increment_retransmit_count(msg_id)

        cursor = self.message_store.db_conn.cursor()
        cursor.execute('''
            SELECT target_addr FROM outgoing_queue WHERE original_msg_id=?
        ''', (msg_id,))
        row = cursor.fetchone()
        if row:
            target_addr = row[0]
            cursor.execute('''
                SELECT nonce, tag, ciphertext FROM messages WHERE msg_id=?
            ''', (msg_id,))
            msg_row = cursor.fetchone()
            if msg_row:
                nonce = msg_row[0]
                tag = msg_row[1]
                ciphertext_b64 = msg_row[2]
                nonce_b64 = base64.b64encode(nonce).decode() if nonce else ""
                tag_b64 = base64.b64encode(tag).decode() if tag else ""
                sign_data = f"{Protocol.VERSION}{target_addr}{msg_id}{nonce_b64}{ciphertext_b64}{self.my_addr}".encode()
                signature = self.crypto.sign(sign_data)
                signature_b64 = base64.b64encode(signature).decode()
                whole_hash = hashlib.sha256(ciphertext_b64.encode()).hexdigest() if ciphertext_b64 else ""
                await self._send_fragment_retransmit(
                    target_addr, msg_id, missing_parts,
                    nonce_b64, tag_b64, signature_b64,
                    ciphertext_b64, total_parts, whole_hash
                )
                logger.debug(f"Пересланы фрагменты {missing_parts} для {msg_id} (ретрансляция {retransmit_count+1})")

    async def _handle_fragment_retransmit_packet(self, from_addr: str, payload: dict, writer: asyncio.StreamWriter):
        msg_id = payload.get("msg_id")
        if msg_id in self.processed_fragmented_msgs:
            logger.debug(f"Игнорируем повторную отправку фрагментов для уже обработанного {msg_id}")
            return
        await self._handle_message(from_addr, payload, writer)

    async def _send_fragment_retransmit(self, to_addr: str, msg_id: str, part_nums: List[int],
                                         nonce_b64: str, tag_b64: str, signature_b64: str,
                                         ciphertext_b64: str, total_parts: int, whole_hash: str):
        max_chunk = 3000
        for part_num in part_nums:
            start = (part_num - 1) * max_chunk
            end = min(start + max_chunk, len(ciphertext_b64))
            chunk = ciphertext_b64[start:end]
            payload = {
                "msg_id": msg_id,
                "part_num": part_num,
                "total_parts": total_parts,
                "signature": signature_b64,
                "nonce": nonce_b64,
                "tag": tag_b64,
                "ciphertext": chunk,
                "whole_hash": whole_hash,
                "timestamp": int(time.time())
            }
            packet = Protocol.build_packet("fragment_retransmit", self.my_addr, to_addr, payload)
            await self._send_raw(to_addr, packet)

    # ========================= ГРУППОВЫЕ СООБЩЕНИЯ =========================
    async def _handle_group_message(self, from_addr: str, payload: dict):
        group_id = payload.get("group_id")
        msg_id = payload.get("msg_id")
        ciphertext_b64 = payload.get("ciphertext")
        nonce_b64 = payload.get("nonce")
        tag_b64 = payload.get("tag")
        signature = base64.b64decode(payload.get("signature", ""))
        timestamp = payload.get("timestamp", 0)

        current_time = time.time()
        if timestamp and (current_time - timestamp) > 60:
            logger.warning(f"Групповое сообщение от {from_addr} слишком старое (timestamp {timestamp})")
            return

        group = self.group_manager.get_group(group_id)
        if not group:
            logger.warning(f"Сообщение для неизвестной группы: {group_id}")
            return

        if from_addr not in group.members:
            logger.warning(f"Отправитель {from_addr} не в группе {group_id}")
            return

        if self.group_manager.is_nonce_used_in_group(group_id, nonce_b64):
            logger.warning(f"Replay группового сообщения от {from_addr} (nonce {nonce_b64})")
            return
        lock = self.group_manager.group_locks.get(group_id)
        if lock:
            async with lock:
                if self.group_manager.is_nonce_used_in_group(group_id, nonce_b64):
                    return
                self.group_manager.store_group_nonce(group_id, nonce_b64)
        else:
            self.group_manager.store_group_nonce(group_id, nonce_b64)

        contact = self.contact_manager.get_contact_by_addr(from_addr)
        if not contact:
            return

        sign_data = f"{Protocol.VERSION}{self.my_addr}{group_id}{msg_id}{ciphertext_b64}{from_addr}".encode()
        if not self.crypto.verify(signature, sign_data, contact.pubkey):
            logger.warning(f"Неверная подпись группового сообщения от {from_addr}")
            return

        sym_key = group.symmetric_key
        if not sym_key:
            logger.error(f"Нет ключа для группы {group_id}")
            await self.group_manager.request_group_sync(group, self)
            return

        try:
            nonce_bytes = base64.b64decode(nonce_b64)
            tag = base64.b64decode(tag_b64)
            ciphertext = base64.b64decode(ciphertext_b64)
            cipher = AESGCM(sym_key)
            ad = f"{group_id}{msg_id}{from_addr}".encode()
            plain = cipher.decrypt(nonce_bytes, ciphertext + tag, ad).decode()
        except Exception as e:
            logger.error(f"Ошибка расшифровки группового сообщения: {e}")
            return

        db_id, msg_hash = self.message_store.save_message(group_id, "group", plain, msg_id)
        if self.on_message_callback:
            await self.on_message_callback(from_addr, f"[Группа {group.name}] {plain}")
        logger.info(f"Групповое сообщение от {from_addr} в {group_id}")
        self.send_notification(f"ZeroTracer: Группа {group.name}", plain[:100])

    async def send_group_message(self, group: Group, text: str):
        msg_id = secrets.token_hex(16)
        sym_key = group.symmetric_key
        if not sym_key:
            logger.error(f"Нет ключа для группы {group.group_id}, сообщение поставлено в очередь")
            msg_hash = hashlib.sha256(f"{group.group_id}{text}{msg_id}".encode()).hexdigest()
            self.message_store.queue_message(group.group_id, text, msg_id, msg_hash,
                                              is_group=True, group_id=group.group_id)
            await self.group_manager.request_group_sync(group, self)
            return

        nonce = os.urandom(12)
        nonce_b64 = base64.b64encode(nonce).decode()

        cipher = AESGCM(sym_key)
        ad = f"{group.group_id}{msg_id}{self.my_addr}".encode()
        encrypted = cipher.encrypt(nonce, text.encode(), ad)
        tag = encrypted[-16:]
        ciphertext = encrypted[:-16]
        ciphertext_b64 = base64.b64encode(ciphertext).decode()
        tag_b64 = base64.b64encode(tag).decode()

        sign_data = f"{Protocol.VERSION}{self.my_addr}{group.group_id}{msg_id}{ciphertext_b64}{self.my_addr}".encode()
        signature = self.crypto.sign(sign_data)
        signature_b64 = base64.b64encode(signature).decode()

        db_id, msg_hash = self.message_store.save_message(group.group_id, "group", text, msg_id, nonce, tag, ciphertext_b64)

        payload = {
            "group_id": group.group_id,
            "msg_id": msg_id,
            "ciphertext": ciphertext_b64,
            "nonce": nonce_b64,
            "tag": tag_b64,
            "signature": signature_b64,
            "timestamp": int(time.time())
        }

        success_count = 0
        for member_addr in group.members:
            if member_addr == self.my_addr:
                continue
            packet = Protocol.build_packet("group_message", self.my_addr, member_addr, payload)
            sent = await self._send_raw(member_addr, packet)
            if sent:
                success_count += 1
            else:
                self.message_store.queue_message(member_addr, f"[GROUP:{group.group_id}]{text}", msg_id, msg_hash,
                                                  is_group=True, group_id=group.group_id)
                logger.debug(f"Групповое сообщение не доставлено {member_addr}")
        if success_count > 0:
            print(f"{C_GREEN}Групповое сообщение отправлено {success_count} участникам.{C_RESET}")
        else:
            print(f"{C_YELLOW}Групповое сообщение не доставлено никому, поставлено в очередь.{C_RESET}")

    # ========================= УПРАВЛЯЮЩИЕ СООБЩЕНИЯ =========================
    async def _handle_key_update(self, from_addr: str, payload: dict):
        new_x25519_pub = payload.get("x25519_pub")
        signature = base64.b64decode(payload.get("signature", ""))
        nonce = payload.get("nonce")
        timestamp = payload.get("timestamp", 0)

        if not nonce or not timestamp:
            logger.warning(f"key_update без nonce/timestamp от {from_addr}")
            return
        current_time = time.time()
        if abs(current_time - timestamp) > 60:
            logger.warning(f"key_update слишком старый от {from_addr}")
            return
        if self.group_manager.is_control_nonce_used(nonce):
            logger.warning(f"Replay key_update от {from_addr}")
            return
        self.group_manager.store_control_nonce(nonce)

        contact = self.contact_manager.get_contact_by_addr(from_addr)
        if not contact:
            logger.warning(f"key_update от неизвестного контакта {from_addr}")
            return
        sign_data = f"{Protocol.VERSION}{self.my_addr}{from_addr}{new_x25519_pub}{nonce}{timestamp}".encode()
        if not self.crypto.verify(signature, sign_data, contact.pubkey):
            logger.warning(f"Неверная подпись key_update от {from_addr}")
            return
        self.contact_manager.update_x25519_key(from_addr, new_x25519_pub)
        logger.info(f"Обновлён X25519 ключ для {from_addr}")

    async def send_key_update(self):
        new_x_pub_b64 = base64.b64encode(self.crypto.public_key_x25519.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )).decode()
        nonce = secrets.token_hex(16)
        timestamp = int(time.time())
        sign_data = f"{Protocol.VERSION}{self.my_addr}{new_x_pub_b64}{nonce}{timestamp}".encode()
        signature = self.crypto.sign(sign_data)
        signature_b64 = base64.b64encode(signature).decode()
        payload = {
            "x25519_pub": new_x_pub_b64,
            "signature": signature_b64,
            "nonce": nonce,
            "timestamp": timestamp
        }
        for contact in self.contact_manager.contacts:
            packet = Protocol.build_packet("key_update", self.my_addr, contact.addr, payload)
            await self._send_raw(contact.addr, packet)
            logger.debug(f"Отправлен key_update для {contact.addr}")

    async def send_group_key_update(self, group: Group):
        for member in group.members:
            if member == self.my_addr:
                continue
            try:
                encrypted_key = self.group_manager.encrypt_group_key_for_recipient(group.symmetric_key, member)
                encrypted_key_b64 = base64.b64encode(encrypted_key).decode()
                nonce = secrets.token_hex(16)
                timestamp = int(time.time())
                sign_data = f"{Protocol.VERSION}{self.my_addr}{group.group_id}{encrypted_key_b64}{nonce}{timestamp}".encode()
                signature = self.crypto.sign(sign_data)
                signature_b64 = base64.b64encode(signature).decode()
                payload = {
                    "group_id": group.group_id,
                    "encrypted_key": encrypted_key_b64,
                    "signature": signature_b64,
                    "nonce": nonce,
                    "timestamp": timestamp
                }
                packet = Protocol.build_packet("group_key_update", self.my_addr, member, payload)
                await self._send_raw(member, packet)
            except Exception as e:
                logger.error(f"Не удалось зашифровать ключ для {member}: {e}")

    async def _handle_group_key_update(self, from_addr: str, payload: dict):
        group_id = payload.get("group_id")
        encrypted_key_b64 = payload.get("encrypted_key")
        signature = base64.b64decode(payload.get("signature", ""))
        nonce = payload.get("nonce")
        timestamp = payload.get("timestamp", 0)

        if not nonce or not timestamp:
            logger.warning(f"group_key_update без nonce/timestamp от {from_addr}")
            return
        current_time = time.time()
        if abs(current_time - timestamp) > 60:
            logger.warning(f"group_key_update слишком старый от {from_addr}")
            return
        if self.group_manager.is_control_nonce_used(nonce):
            logger.warning(f"Replay group_key_update от {from_addr}")
            return
        self.group_manager.store_control_nonce(nonce)

        group = self.group_manager.get_group(group_id)
        if not group:
            logger.warning(f"group_key_update для неизвестной группы {group_id}")
            return
        if from_addr != group.creator:
            logger.warning(f"group_key_update от {from_addr} не является создателем")
            return
        contact = self.contact_manager.get_contact_by_addr(from_addr)
        if not contact:
            return
        sign_data = f"{Protocol.VERSION}{self.my_addr}{from_addr}{group_id}{encrypted_key_b64}{nonce}{timestamp}".encode()
        if not self.crypto.verify(signature, sign_data, contact.pubkey):
            logger.warning(f"Неверная подпись group_key_update")
            return
        try:
            encrypted_key = base64.b64decode(encrypted_key_b64)
            new_sym_key = self.group_manager.decrypt_group_key_from_sender(encrypted_key, from_addr)
            group.symmetric_key = new_sym_key
            self.group_manager.save_group(group)
            logger.info(f"Ключ группы {group_id} обновлён")
        except Exception as e:
            logger.error(f"Ошибка расшифровки ключа группы: {e}")

    async def send_group_sync(self, group: Group, retries: int = 3):
        members_json = json.dumps(group.members).encode()
        for member_addr in group.members:
            if member_addr == self.my_addr:
                continue
            try:
                enc_members = self.group_manager.encrypt_group_key_for_recipient(members_json, member_addr)
                enc_members_b64 = base64.b64encode(enc_members).decode()
                nonce = secrets.token_hex(16)
                timestamp = int(time.time())
                sign_data = f"{Protocol.VERSION}{self.my_addr}{group.group_id}{enc_members_b64}{nonce}{timestamp}".encode()
                signature = self.crypto.sign(sign_data)
                signature_b64 = base64.b64encode(signature).decode()
                payload = {
                    "group_id": group.group_id,
                    "encrypted_members": enc_members_b64,
                    "signature": signature_b64,
                    "creator": group.creator,
                    "nonce": nonce,
                    "timestamp": timestamp
                }
                packet = Protocol.build_packet("group_sync", self.my_addr, member_addr, payload)
                for attempt in range(retries):
                    if await self._send_raw(member_addr, packet):
                        break
                    await asyncio.sleep(1)
                else:
                    logger.warning(f"Не удалось отправить group_sync для {member_addr}")
            except Exception as e:
                logger.error(f"Ошибка шифрования group_sync для {member_addr}: {e}")

    async def _handle_group_sync(self, from_addr: str, payload: dict):
        group_id = payload.get("group_id")
        encrypted_members_b64 = payload.get("encrypted_members")
        signature = base64.b64decode(payload.get("signature", ""))
        creator = payload.get("creator")
        nonce = payload.get("nonce")
        timestamp = payload.get("timestamp", 0)

        if not nonce or not timestamp:
            logger.warning(f"group_sync без nonce/timestamp от {from_addr}")
            return
        current_time = time.time()
        if abs(current_time - timestamp) > 60:
            logger.warning(f"group_sync слишком старый от {from_addr}")
            return
        if self.group_manager.is_control_nonce_used(nonce):
            logger.warning(f"Replay group_sync от {from_addr}")
            return
        self.group_manager.store_control_nonce(nonce)

        group = self.group_manager.get_group(group_id)
        if not group:
            logger.warning(f"Group sync для неизвестной группы {group_id}")
            return

        if from_addr != group.creator:
            logger.warning(f"Group sync от {from_addr} не является создателем группы")
            return

        contact = self.contact_manager.get_contact_by_addr(group.creator)
        if not contact:
            logger.warning(f"Неизвестный создатель группы {group.creator}")
            return
        sign_data = f"{Protocol.VERSION}{self.my_addr}{from_addr}{group_id}{encrypted_members_b64}{nonce}{timestamp}".encode()
        if not self.crypto.verify(signature, sign_data, contact.pubkey):
            logger.warning(f"Неверная подпись group sync")
            return

        try:
            encrypted_members = base64.b64decode(encrypted_members_b64)
            decrypted = self.group_manager.decrypt_group_key_from_sender(encrypted_members, group.creator)
            members = json.loads(decrypted.decode())
        except Exception as e:
            logger.error(f"Ошибка расшифровки списка участников: {e}")
            return

        group.members = members[:]
        self.group_manager.save_group(group)
        logger.info(f"Синхронизирован список участников группы {group_id}: {len(members)} участников")
        print(f"\n{C_MAGENTA}[Группа] Список участников '{group.name}' обновлён{C_RESET}")
        print(f"{C_GREEN}> {C_RESET}", end="", flush=True)

    async def _handle_group_sync_request(self, from_addr: str, payload: dict):
        group_id = payload.get("group_id")
        nonce = payload.get("nonce")
        timestamp = payload.get("timestamp", 0)
        signature_b64 = payload.get("signature")
        if not nonce or not timestamp or not signature_b64:
            return
        current_time = time.time()
        if abs(current_time - timestamp) > 60:
            return
        if self.group_manager.is_control_nonce_used(nonce):
            return
        self.group_manager.store_control_nonce(nonce)

        group = self.group_manager.get_group(group_id)
        if not group or group.creator != self.my_addr:
            logger.warning(f"Запрос синхронизации группы {group_id} от {from_addr}, но я не создатель")
            return

        if from_addr not in group.members:
            logger.warning(f"Запрос синхронизации от {from_addr}, не состоящего в группе {group_id}")
            return

        contact = self.contact_manager.get_contact_by_addr(from_addr)
        if not contact:
            logger.warning(f"Неизвестный контакт {from_addr} для group_sync_request")
            return
        sign_data = f"{Protocol.VERSION}{self.my_addr}{from_addr}{group_id}{nonce}{timestamp}".encode()
        try:
            signature = base64.b64decode(signature_b64)
        except:
            logger.warning(f"Неверный base64 подписи group_sync_request от {from_addr}")
            return
        if not self.crypto.verify(signature, sign_data, contact.pubkey):
            logger.warning(f"Неверная подпись group_sync_request от {from_addr}")
            return

        await self.send_group_sync(group)

    async def send_group_invite(self, group: Group, member_addr: str, retries: int = 3):
        try:
            encrypted_key = self.group_manager.encrypt_group_key_for_recipient(group.symmetric_key, member_addr)
            encrypted_key_b64 = base64.b64encode(encrypted_key).decode()
        except Exception as e:
            logger.error(f"Не удалось зашифровать ключ для {member_addr}: {e}")
            return
        nonce = secrets.token_hex(16)
        timestamp = int(time.time())
        sign_data = f"{Protocol.VERSION}{self.my_addr}{group.group_id}{group.name}{encrypted_key_b64}{nonce}{timestamp}".encode()
        signature = self.crypto.sign(sign_data)
        signature_b64 = base64.b64encode(signature).decode()
        payload = {
            "group_id": group.group_id,
            "group_name": group.name,
            "encrypted_key": encrypted_key_b64,
            "creator": group.creator,
            "members": group.members,
            "signature": signature_b64,
            "nonce": nonce,
            "timestamp": timestamp
        }
        packet = Protocol.build_packet("group_invite", self.my_addr, member_addr, payload)
        for attempt in range(retries):
            if await self._send_raw(member_addr, packet):
                logger.debug(f"Приглашение в группу отправлено {member_addr}")
                return
            await asyncio.sleep(1)
        logger.warning(f"Не удалось отправить приглашение в группу {member_addr} после {retries} попыток")

    async def _handle_group_invite(self, from_addr: str, payload: dict):
        group_id = payload.get("group_id")
        group_name = payload.get("group_name")
        encrypted_key_b64 = payload.get("encrypted_key")
        creator = payload.get("creator")
        members = payload.get("members", [])
        signature = base64.b64decode(payload.get("signature", ""))
        nonce = payload.get("nonce")
        timestamp = payload.get("timestamp", 0)

        if not nonce or not timestamp:
            logger.warning(f"group_invite без nonce/timestamp от {from_addr}")
            return
        current_time = time.time()
        if abs(current_time - timestamp) > 60:
            logger.warning(f"group_invite слишком старый от {from_addr}")
            return
        if self.group_manager.is_control_nonce_used(nonce):
            logger.warning(f"Replay group_invite от {from_addr}")
            return
        self.group_manager.store_control_nonce(nonce)

        if from_addr != creator:
            logger.warning(f"group_invite от {from_addr}, но creator={creator}")
            return

        contact = self.contact_manager.get_contact_by_addr(from_addr)
        if not contact:
            logger.warning(f"group_invite от неизвестного {from_addr}")
            return
        sign_data = f"{Protocol.VERSION}{self.my_addr}{from_addr}{group_id}{group_name}{encrypted_key_b64}{nonce}{timestamp}".encode()
        if not self.crypto.verify(signature, sign_data, contact.pubkey):
            logger.warning(f"Неверная подпись group_invite")
            return

        try:
            encrypted_key = base64.b64decode(encrypted_key_b64)
            sym_key = self.group_manager.decrypt_group_key_from_sender(encrypted_key, from_addr)

            existing_group = self.group_manager.get_group(group_id)
            if existing_group:
                existing_group.name = group_name
                existing_group.creator = creator
                existing_group.members = members
                existing_group.symmetric_key = sym_key
                self.group_manager.save_group(existing_group)
                logger.info(f"Группа {group_id} обновлена (повторное приглашение)")
            else:
                group = Group(
                    group_id=group_id, name=group_name, creator=creator,
                    symmetric_key_enc=b'', members=members, created_at=time.time(),
                    symmetric_key=sym_key
                )
                self.group_manager.groups[group_id] = group
                self.group_manager.save_group(group)
                self.group_manager.group_locks[group_id] = asyncio.Lock()
                logger.info(f"Принято приглашение в группу {group_name} ({group_id})")
                print(f"\n{C_GREEN}Вы добавлены в группу '{group_name}'!{C_RESET}")
            print(f"{C_GREEN}> {C_RESET}", end="", flush=True)
        except Exception as e:
            logger.error(f"Ошибка принятия приглашения: {e}")

    # ========================= ПИНГ / ПОНГ =========================
    async def _handle_ping(self, from_addr: str, payload: dict, writer: asyncio.StreamWriter):
        signature_b64 = payload.get("signature")
        timestamp = payload.get("timestamp", 0)
        nonce = payload.get("nonce", "")
        if not signature_b64 or not timestamp or not nonce:
            logger.warning(f"Ping от {from_addr} без подписи/timestamp/nonce")
            return
        current_time = time.time()
        if abs(current_time - timestamp) > 60:
            logger.warning(f"Ping от {from_addr} слишком старый")
            return
        if self.group_manager.is_control_nonce_used(nonce):
            logger.warning(f"Replay ping от {from_addr}")
            return
        self.group_manager.store_control_nonce(nonce)

        contact = self.contact_manager.get_contact_by_addr(from_addr)
        if not contact:
            logger.warning(f"Ping от неизвестного {from_addr}")
            return
        sign_data = f"{Protocol.VERSION}{self.my_addr}{from_addr}{timestamp}{nonce}".encode()
        try:
            signature = base64.b64decode(signature_b64)
        except:
            logger.warning(f"Неверный base64 подписи ping от {from_addr}")
            return
        if not self.crypto.verify(signature, sign_data, contact.pubkey):
            logger.warning(f"Неверная подпись ping от {from_addr}")
            return

        pong_nonce = secrets.token_hex(16)
        pong_timestamp = int(time.time())
        pong_sign_data = f"{Protocol.VERSION}{from_addr}{self.my_addr}{pong_timestamp}{pong_nonce}".encode()
        pong_signature = self.crypto.sign(pong_sign_data)
        pong_payload = {
            "timestamp": pong_timestamp,
            "nonce": pong_nonce,
            "signature": base64.b64encode(pong_signature).decode()
        }
        pong_packet = Protocol.build_packet("pong", self.my_addr, from_addr, pong_payload)
        await self._send_raw(from_addr, pong_packet)
        self.contact_manager.set_online(from_addr, True)

    async def _handle_pong(self, from_addr: str, payload: dict):
        signature_b64 = payload.get("signature")
        timestamp = payload.get("timestamp", 0)
        nonce = payload.get("nonce", "")
        if not signature_b64 or not timestamp or not nonce:
            logger.warning(f"Pong от {from_addr} без подписи/timestamp/nonce")
            return
        current_time = time.time()
        if abs(current_time - timestamp) > 60:
            logger.warning(f"Pong от {from_addr} слишком старый")
            return
        if self.group_manager.is_control_nonce_used(nonce):
            logger.warning(f"Replay pong от {from_addr}")
            return
        self.group_manager.store_control_nonce(nonce)

        contact = self.contact_manager.get_contact_by_addr(from_addr)
        if not contact:
            logger.warning(f"Pong от неизвестного {from_addr}")
            return
        sign_data = f"{Protocol.VERSION}{self.my_addr}{from_addr}{timestamp}{nonce}".encode()
        try:
            signature = base64.b64decode(signature_b64)
        except:
            logger.warning(f"Неверный base64 подписи pong от {from_addr}")
            return
        if not self.crypto.verify(signature, sign_data, contact.pubkey):
            logger.warning(f"Неверная подпись pong от {from_addr}")
            return

        self.contact_manager.set_online(from_addr, True)

    # ========================= ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ =========================
    async def _send_raw(self, target_addr: str, packet: str, max_retries: int = 3) -> bool:
        writer = None
        for attempt in range(max_retries):
            try:
                nick, host, port = self._parse_addr(target_addr)
                if not host:
                    return False

                if self.use_tor:
                    if not AIO_SOCKS_AVAILABLE:
                        logger.error("Для Tor требуется aio_socks. Установите: pip install aio_socks")
                        return False
                    try:
                        reader, writer = await asyncio.wait_for(
                            aio_socks.open_connection(
                                host=host, port=port,
                                proxy_type=aio_socks.SOCKS5,
                                proxy_host="127.0.0.1",
                                proxy_port=9050
                            ),
                            timeout=15
                        )
                        writer.write(packet.encode())
                        await writer.drain()
                        writer.close()
                        await writer.wait_closed()
                        return True
                    except Exception as e:
                        logger.debug(f"Async SOCKS send error to {target_addr} (attempt {attempt+1}): {e}")
                else:
                    try:
                        reader, writer = await asyncio.wait_for(
                            asyncio.open_connection(host, port),
                            timeout=15
                        )
                        writer.write(packet.encode())
                        await writer.drain()
                        writer.close()
                        await writer.wait_closed()
                        return True
                    except Exception as e:
                        logger.debug(f"Async send error to {target_addr} (attempt {attempt+1}): {e}")
                if attempt < max_retries - 1:
                    await asyncio.sleep(0.5)
            except Exception as e:
                logger.debug(f"Send error (attempt {attempt+1}) to {target_addr}: {e}")
                if attempt < max_retries - 1:
                    await asyncio.sleep(0.5)
            finally:
                if writer:
                    try:
                        writer.close()
                        await writer.wait_closed()
                    except:
                        pass
        return False

    async def _send_fragmented_message(self, contact: Contact, msg_id: str, ciphertext_b64: str,
                                        nonce: bytes, tag: bytes, signature_b64: str) -> bool:
        max_chunk = 3000
        total = (len(ciphertext_b64) + max_chunk - 1) // max_chunk
        if total > self.message_store.MAX_FRAGMENTS:
            logger.error(f"Слишком много фрагментов ({total}) для сообщения")
            return False
        whole_hash = hashlib.sha256(ciphertext_b64.encode()).hexdigest()
        nonce_b64 = base64.b64encode(nonce).decode()
        tag_b64 = base64.b64encode(tag).decode()
        all_sent = True
        for i in range(total):
            chunk = ciphertext_b64[i*max_chunk:(i+1)*max_chunk]
            payload = {
                "msg_id": msg_id,
                "part_num": i+1,
                "total_parts": total,
                "signature": signature_b64,
                "nonce": nonce_b64,
                "tag": tag_b64,
                "ciphertext": chunk,
                "whole_hash": whole_hash,
                "timestamp": int(time.time())
            }
            packet = Protocol.build_packet("message", self.my_addr, contact.addr, payload)
            sent = await self._send_raw(contact.addr, packet)
            if not sent:
                all_sent = False
                logger.warning(f"Не удалось отправить фрагмент {i+1}/{total}")
            else:
                logger.debug(f"Отправлен фрагмент {i+1}/{total}")
        return all_sent

    async def send_message(self, contact: Contact, text: str):
        shared_secret = self.contact_manager.compute_shared_secret(contact)
        msg_id = secrets.token_hex(16)
        associated_data = f"{msg_id}{self.my_addr}{contact.addr}".encode()
        ciphertext_b64, nonce, tag = self.crypto.encrypt_message(text, shared_secret, associated_data)
        nonce_b64 = base64.b64encode(nonce).decode()
        tag_b64 = base64.b64encode(tag).decode()
        sign_data = f"{Protocol.VERSION}{contact.addr}{msg_id}{nonce_b64}{ciphertext_b64}{self.my_addr}".encode()
        signature = self.crypto.sign(sign_data)
        signature_b64 = base64.b64encode(signature).decode()
        db_id, msg_hash = self.message_store.save_message(contact.addr, "out", text, msg_id, nonce, tag, ciphertext_b64)

        max_chunk = 3000
        if len(ciphertext_b64) > max_chunk:
            all_sent = await self._send_fragmented_message(contact, msg_id, ciphertext_b64, nonce, tag, signature_b64)
            if not all_sent:
                self.message_store.queue_message(contact.addr, text, msg_id, msg_hash, is_group=False)
                logger.info(f"Некоторые фрагменты не отправлены, сообщение в очереди")
                print(f"{C_YELLOW}Сообщение частично отправлено, поставлено в очередь.{C_RESET}")
            else:
                print(f"{C_GREEN}Сообщение отправлено (фрагментировано).{C_RESET}")
        else:
            payload = {
                "msg_id": msg_id,
                "signature": signature_b64,
                "nonce": nonce_b64,
                "tag": tag_b64,
                "ciphertext": ciphertext_b64,
                "timestamp": int(time.time())
            }
            packet = Protocol.build_packet("message", self.my_addr, contact.addr, payload)
            sent = await self._send_raw(contact.addr, packet)
            if not sent:
                self.message_store.queue_message(contact.addr, text, msg_id, msg_hash, is_group=False)
                logger.info("Сообщение поставлено в очередь")
                print(f"{C_YELLOW}Сообщение не доставлено, поставлено в очередь.{C_RESET}")
            else:
                print(f"{C_GREEN}Сообщение отправлено.{C_RESET}")

    async def process_queue(self):
        await asyncio.sleep(5)
        while self.running:
            try:
                queued = self.message_store.get_queued_messages()
                for (qid, target_addr, plain_text, msg_hash, original_msg_id, is_group, group_id, attempts) in queued:
                    if attempts >= self.message_store.MAX_QUEUE_ATTEMPTS:
                        self.message_store.delete_queued(qid)
                        continue
                    if self.message_store.is_message_delivered(original_msg_id):
                        logger.debug(f"Сообщение {original_msg_id} уже доставлено, удаляем из очереди")
                        self.message_store.delete_queued(qid)
                        continue
                    if is_group:
                        cursor = self.message_store.db_conn.cursor()
                        cursor.execute('''
                            SELECT msg_id, nonce, tag, ciphertext FROM messages
                            WHERE msg_id=? AND remote_addr=?
                        ''', (original_msg_id, group_id))
                        row = cursor.fetchone()
                        if not row:
                            logger.warning(f"Групповое сообщение {original_msg_id} не найдено в БД, удаляем из очереди")
                            self.message_store.delete_queued(qid)
                            continue
                        stored_msg_id, nonce, tag, ciphertext_b64 = row
                        if nonce is None or tag is None or ciphertext_b64 is None:
                            logger.error(f"Неполные данные для группового сообщения {original_msg_id}")
                            self.message_store.delete_queued(qid)
                            continue

                        group = self.group_manager.get_group(group_id)
                        if not group or target_addr not in group.members:
                            logger.warning(f"Получатель {target_addr} больше не в группе {group_id}, удаляем из очереди")
                            self.message_store.delete_queued(qid)
                            continue

                        nonce_b64 = base64.b64encode(nonce).decode()
                        tag_b64 = base64.b64encode(tag).decode()
                        sign_data = f"{Protocol.VERSION}{target_addr}{group_id}{stored_msg_id}{ciphertext_b64}{self.my_addr}".encode()
                        signature = self.crypto.sign(sign_data)
                        signature_b64 = base64.b64encode(signature).decode()

                        payload = {
                            "group_id": group_id,
                            "msg_id": stored_msg_id,
                            "ciphertext": ciphertext_b64,
                            "nonce": nonce_b64,
                            "tag": tag_b64,
                            "signature": signature_b64,
                            "timestamp": int(time.time())
                        }
                        packet = Protocol.build_packet("group_message", self.my_addr, target_addr, payload)
                        sent = await self._send_raw(target_addr, packet, max_retries=1)
                        if sent:
                            self.message_store.delete_queued(qid)
                            logger.info(f"Очередное групповое сообщение доставлено {target_addr}")
                        else:
                            if self.message_store.increment_attempts(qid):
                                logger.warning(f"Групповое сообщение к {target_addr} удалено после {self.message_store.MAX_QUEUE_ATTEMPTS} попыток")
                    else:
                        contact = self.contact_manager.get_contact_by_addr(target_addr)
                        if not contact:
                            self.message_store.delete_queued(qid)
                            continue
                        shared_secret = self.contact_manager.compute_shared_secret(contact)
                        msg_id = original_msg_id
                        associated_data = f"{msg_id}{self.my_addr}{target_addr}".encode()
                        ciphertext_b64, nonce, tag = self.crypto.encrypt_message(plain_text, shared_secret, associated_data)
                        nonce_b64 = base64.b64encode(nonce).decode()
                        tag_b64 = base64.b64encode(tag).decode()
                        sign_data = f"{Protocol.VERSION}{target_addr}{msg_id}{nonce_b64}{ciphertext_b64}{self.my_addr}".encode()
                        signature = self.crypto.sign(sign_data)
                        signature_b64 = base64.b64encode(signature).decode()
                        payload = {
                            "msg_id": msg_id,
                            "signature": signature_b64,
                            "nonce": nonce_b64,
                            "tag": tag_b64,
                            "ciphertext": ciphertext_b64,
                            "timestamp": int(time.time())
                        }
                        packet = Protocol.build_packet("message", self.my_addr, target_addr, payload)
                        sent = await self._send_raw(target_addr, packet, max_retries=1)
                        if sent:
                            self.message_store.delete_queued(qid)
                            logger.info(f"Очередное сообщение доставлено {target_addr}")
                        else:
                            if self.message_store.increment_attempts(qid):
                                logger.warning(f"Сообщение к {target_addr} удалено после {self.message_store.MAX_QUEUE_ATTEMPTS} попыток")
            except Exception as e:
                logger.error(f"Process queue error: {e}")
            await asyncio.sleep(30)

    async def cleanup_fragments_loop(self):
        while self.running:
            await asyncio.sleep(60)
            self.message_store.cleanup_old_fragments()
            now = time.time()
            to_delete = [key for key, ts in self.pending_fragments_timestamp.items() if now - ts > 60]
            for key in to_delete:
                if key in self.pending_fragments:
                    del self.pending_fragments[key]
                if key in self.pending_fragment_meta:
                    del self.pending_fragment_meta[key]
                del self.pending_fragments_timestamp[key]
                logger.debug(f"Очищены устаревшие pending фрагменты для {key}")
            if len(self.pending_fragments) > 1000:
                sorted_keys = sorted(self.pending_fragments_timestamp.items(), key=lambda x: x[1])
                excess = len(self.pending_fragments) - 1000
                for key, _ in sorted_keys[:excess]:
                    if key in self.pending_fragments:
                        del self.pending_fragments[key]
                    if key in self.pending_fragment_meta:
                        del self.pending_fragment_meta[key]
                    del self.pending_fragments_timestamp[key]
                    logger.debug(f"Очищены старые pending фрагменты (превышен лимит 1000) для {key}")
            if len(self.processed_fragmented_msgs) > 1000:
                self.processed_fragmented_msgs.clear()

    async def cleanup_messages_loop(self):
        while self.running:
            await asyncio.sleep(86400)
            self.message_store.cleanup_old_messages(days=30)

    async def rotate_x25519_key(self):
        if self.crypto.rotate_x25519_key():
            print(f"{C_GREEN}X25519 ключ успешно сменён (PFS). Рассылка нового ключа...{C_RESET}")
            await self.send_key_update()
        else:
            print(f"{C_RED}Ошибка ротации X25519 ключа.{C_RESET}")

    async def pfs_rotation_loop(self):
        await asyncio.sleep(3600)
        while self.running:
            await self.rotate_x25519_key()
            await asyncio.sleep(86400)

    async def ping_loop(self):
        await asyncio.sleep(10)
        while self.running:
            try:
                contacts = self.contact_manager.contacts
                if contacts:
                    import random
                    targets = random.sample(contacts, min(3, len(contacts)))
                    for contact in targets:
                        nonce = secrets.token_hex(16)
                        timestamp = int(time.time())
                        sign_data = f"{Protocol.VERSION}{contact.addr}{self.my_addr}{timestamp}{nonce}".encode()
                        signature = self.crypto.sign(sign_data)
                        ping_payload = {
                            "timestamp": timestamp,
                            "nonce": nonce,
                            "signature": base64.b64encode(signature).decode()
                        }
                        ping_packet = Protocol.build_packet("ping", self.my_addr, contact.addr, ping_payload)
                        sent = await self._send_raw(contact.addr, ping_packet)
                        if not sent:
                            self.contact_manager.set_online(contact.addr, False)
                        logger.debug(f"Ping отправлен {contact.addr}: {'успех' if sent else 'неудача'}")
            except Exception as e:
                logger.error(f"Ping loop error: {e}")
            await asyncio.sleep(120)

    async def address_update_loop(self):
        await asyncio.sleep(60)
        while self.running:
            try:
                old_addr = self.my_addr
                self._update_my_address()
                if old_addr != self.my_addr:
                    logger.info(f"Адрес обновлён: {self.my_addr}")
                    self._save_config()
            except Exception as e:
                logger.error(f"Address update error: {e}")
            await asyncio.sleep(1800 + secrets.randbelow(1800))

    async def tor_restart_callback(self, new_onion: str):
        self.onion_host = new_onion
        self._update_my_address()
        self._save_config()
        await self.send_key_update()

    def _parse_addr(self, addr_str: str) -> Tuple[Optional[str], Optional[str], Optional[int]]:
        try:
            nick, rest = addr_str.split('@')
            if ':' in rest:
                host, port_str = rest.rsplit(':', 1)
                port = int(port_str)
            else:
                host = rest
                port = 80
            if host in ('localhost', '127.0.0.1', '0.0.0.0', '::1') and not self.use_tor:
                logger.warning(f"Попытка соединения с локальным адресом {host} отклонена")
                return None, None, None
            return nick, host, port
        except:
            return None, None, None

    async def stop(self):
        self.running = False
        self.tor_manager.running = False
        for server in self.servers:
            try:
                server.close()
                await server.wait_closed()
            except:
                pass
        self.tor_manager.stop_hidden_service()
        self.db_conn.close()

# ----------------------------------------------------------------------
# Текстовый пользовательский интерфейс (консольный)
# ----------------------------------------------------------------------
class ConsoleUI:
    def __init__(self, app: ZeroTracerAsync):
        self.app = app
        self.app.on_message_callback = self.on_message

    async def on_message(self, from_addr: str, text: str):
        contact = self.app.contact_manager.get_contact_by_addr(from_addr)
        nick = contact.nick if contact else from_addr
        print(f"\n{C_CYAN}[⇢ Новое сообщение] от {nick}: {text}{C_RESET}")
        print(f"{C_GREEN}> {C_RESET}", end="", flush=True)

    async def run(self):
        print(BANNER)
        print(f"{C_CYAN}Ваш ID: {self.app.my_addr}{C_RESET}")
        print(f"{C_GRAY}Команды:{C_RESET}")
        print(f"  {C_YELLOW}/help{C_RESET}              - показать справку")
        print(f"  {C_YELLOW}/mykey{C_RESET}            - показать свой ключ и QR-URL")
        print(f"  {C_YELLOW}/add <url>|...{C_RESET}   - добавить контакт (URL или ручной ввод)")
        print(f"  {C_YELLOW}/send <idx> <text>{C_RESET} - отправить сообщение")
        print(f"  {C_YELLOW}/list{C_RESET}            - список контактов")
        print(f"  {C_YELLOW}/online{C_RESET}          - онлайн контакты")
        print(f"  {C_YELLOW}/del <idx>{C_RESET}       - удалить контакт")
        print(f"  {C_YELLOW}/newnick <nick>{C_RESET}  - сменить ник")
        print(f"  {C_YELLOW}/history [idx]{C_RESET}   - история (всех или контакта)")
        print(f"  {C_YELLOW}/read <idx>{C_RESET}      - отметить сообщения контакта прочитанными")
        print(f"  {C_YELLOW}/resend{C_RESET}          - принудительная отправка очереди")
        print(f"  {C_YELLOW}/rotate{C_RESET}          - принудительная ротация X25519 ключа (PFS)")
        print(f"  {C_YELLOW}/group create <name>{C_RESET} - создать группу")
        print(f"  {C_YELLOW}/group add <gid> <idx>{C_RESET} - добавить участника в группу")
        print(f"  {C_YELLOW}/group remove <gid> <idx>{C_RESET} - удалить участника из группы")
        print(f"  {C_YELLOW}/group rotatekey <gid>{C_RESET} - сменить ключ группы")
        print(f"  {C_YELLOW}/group send <gid> <text>{C_RESET} - отправить в группу")
        print(f"  {C_YELLOW}/group list{C_RESET}      - список групп")
        print(f"  {C_YELLOW}/group members <gid>{C_RESET} - список участников группы")
        print(f"  {C_YELLOW}/group sync <gid>{C_RESET}   - запросить синхронизацию группы у создателя")
        print(f"  {C_YELLOW}/notify on|off{C_RESET}   - управление уведомлениями")
        print(f"  {C_YELLOW}/log [N]{C_RESET}         - показать последние N строк лога")
        print(f"  {C_YELLOW}/exit{C_RESET}            - выход")

        asyncio.create_task(self.app.process_queue())
        asyncio.create_task(self.app.cleanup_fragments_loop())
        asyncio.create_task(self.app.cleanup_messages_loop())
        asyncio.create_task(self.app.ping_loop())
        asyncio.create_task(self.app.address_update_loop())
        asyncio.create_task(self.app.pfs_rotation_loop())
        if self.app.use_tor:
            asyncio.create_task(self.app.tor_manager.monitor_tor(self.app.tor_restart_callback))

        while self.app.running:
            try:
                cmd = await asyncio.get_event_loop().run_in_executor(None, input, f"{C_GREEN}> {C_RESET}")
                if not cmd:
                    continue
                if cmd == "/exit":
                    self.app.running = False
                    break
                elif cmd == "/help":
                    self._show_help()
                elif cmd == "/list":
                    self._show_contacts()
                elif cmd == "/online":
                    self._show_contacts(only_online=True)
                elif cmd == "/mykey":
                    self._show_mykey()
                elif cmd == "/rotate":
                    await self.app.rotate_x25519_key()
                elif cmd.startswith("/add "):
                    arg = cmd[5:].strip()
                    if arg.startswith("zerotracer:add?"):
                        self.app.contact_manager.add_contact_from_url(arg)
                    else:
                        parts = arg.split(maxsplit=2)
                        if len(parts) >= 3:
                            try:
                                self.app.contact_manager.add_contact_interactive(parts[0], parts[1], parts[2])
                            except Exception as e:
                                print(f"{C_RED}{e}{C_RESET}")
                        else:
                            print("Использование: /add <nick@host:port> <pubkey_b64> <x25519_pub_b64>")
                            print("Или: /add zerotracer:add?nick=...&addr=...&pubkey=...&x25519=...")
                elif cmd.startswith("/del "):
                    try:
                        idx = int(cmd.split()[1])
                        if 0 <= idx < len(self.app.contact_manager.contacts):
                            self.app.contact_manager.delete_contact(self.app.contact_manager.contacts[idx].addr)
                            print("Контакт удалён.")
                        else:
                            print("Неверный индекс")
                    except:
                        print("Неверный формат")
                elif cmd.startswith("/send "):
                    parts = cmd.split(maxsplit=2)
                    if len(parts) < 3:
                        print("Использование: /send <индекс> <сообщение>")
                    else:
                        try:
                            idx = int(parts[1])
                            text = parts[2]
                            if 0 <= idx < len(self.app.contact_manager.contacts):
                                await self.app.send_message(self.app.contact_manager.contacts[idx], text)
                            else:
                                print("Неверный индекс")
                        except:
                            print("Неверный формат")
                elif cmd == "/resend":
                    await self.app.process_queue()
                    print("Очередь обработана.")
                elif cmd.startswith("/newnick "):
                    new_nick = cmd.split(maxsplit=1)[1].strip()
                    self.app.nick = new_nick
                    self.app._update_my_address()
                    self.app._save_config()
                    print(f"Ник изменён, новый ID: {self.app.my_addr}")
                elif cmd.startswith("/read "):
                    try:
                        idx = int(cmd.split()[1])
                        if 0 <= idx < len(self.app.contact_manager.contacts):
                            contact = self.app.contact_manager.contacts[idx]
                            unread = self.app.message_store.get_unread_messages(contact.addr)
                            for db_id, msg_id in unread:
                                await self.app._send_read_receipt(contact.addr, msg_id)
                                self.app.message_store.mark_read(db_id)
                            print(f"Отправлены read receipt для {len(unread)} сообщений.")
                        else:
                            print("Неверный индекс")
                    except:
                        print("Неверный формат")
                elif cmd == "/history":
                    await self._show_history()
                elif cmd.startswith("/history "):
                    try:
                        idx = int(cmd.split()[1])
                        if 0 <= idx < len(self.app.contact_manager.contacts):
                            await self._show_history(contact_idx=idx)
                        else:
                            print("Неверный индекс")
                    except:
                        print("Неверный формат")
                elif cmd.startswith("/group create "):
                    name = cmd[14:].strip()
                    if name:
                        group = self.app.group_manager.create_group(name, self.app.my_addr)
                        print(f"{C_GREEN}Группа '{name}' создана (ID: {group.group_id}){C_RESET}")
                    else:
                        print("Использование: /group create <имя>")
                elif cmd.startswith("/group add "):
                    parts = cmd.split()
                    if len(parts) >= 4:
                        gid = parts[2]
                        idx = int(parts[3])
                        if 0 <= idx < len(self.app.contact_manager.contacts):
                            member = self.app.contact_manager.contacts[idx]
                            group = self.app.group_manager.get_group(gid)
                            if group:
                                if self.app.group_manager.add_member(gid, member.addr):
                                    await self.app.send_group_invite(group, member.addr)
                                    await self.app.send_group_sync(group)
                                    print(f"{C_GREEN}Участник {member.nick} добавлен в группу.{C_RESET}")
                                else:
                                    print("Участник уже в группе.")
                            else:
                                print("Группа не найдена.")
                        else:
                            print("Неверный индекс контакта")
                    else:
                        print("Использование: /group add <group_id> <индекс_контакта>")
                elif cmd.startswith("/group remove "):
                    parts = cmd.split()
                    if len(parts) >= 4:
                        gid = parts[2]
                        idx = int(parts[3])
                        if 0 <= idx < len(self.app.contact_manager.contacts):
                            member = self.app.contact_manager.contacts[idx]
                            group = self.app.group_manager.get_group(gid)
                            if group:
                                if self.app.group_manager.remove_member(gid, member.addr, self.app.my_addr):
                                    await self.app.send_group_sync(group)
                                    await self.app.send_group_key_update(group)
                                    print(f"{C_GREEN}Участник {member.nick} удалён из группы.{C_RESET}")
                                else:
                                    print("Не удалось удалить (возможно, вы не создатель).")
                            else:
                                print("Группа не найдена.")
                        else:
                            print("Неверный индекс контакта")
                    else:
                        print("Использование: /group remove <group_id> <индекс_контакта>")
                elif cmd.startswith("/group rotatekey "):
                    parts = cmd.split()
                    if len(parts) >= 3:
                        gid = parts[2]
                        group = self.app.group_manager.get_group(gid)
                        if group:
                            new_key = self.app.group_manager.rotate_group_key(gid, self.app.my_addr)
                            if new_key:
                                await self.app.send_group_key_update(group)
                                print(f"{C_GREEN}Ключ группы сменён и разослан участникам.{C_RESET}")
                            else:
                                print("Не удалось сменить ключ (только создатель).")
                        else:
                            print("Группа не найдена.")
                    else:
                        print("Использование: /group rotatekey <group_id>")
                elif cmd.startswith("/group send "):
                    parts = cmd.split(maxsplit=2)
                    if len(parts) >= 3:
                        sub_parts = parts[1].split()
                        if len(sub_parts) >= 1:
                            gid = sub_parts[0]
                            text = parts[2] if len(sub_parts) == 1 else cmd.split(maxsplit=2)[2]
                            group = self.app.group_manager.get_group(gid)
                            if group:
                                await self.app.send_group_message(group, text)
                            else:
                                print("Группа не найдена.")
                    else:
                        print("Использование: /group send <group_id> <текст>")
                elif cmd == "/group list":
                    groups = self.app.group_manager.list_groups()
                    if not groups:
                        print("Нет групп")
                    else:
                        for g in groups:
                            print(f"  {g.group_id}: {g.name} ({len(g.members)} участников)")
                elif cmd.startswith("/group members "):
                    parts = cmd.split()
                    if len(parts) == 3:
                        gid = parts[2]
                        group = self.app.group_manager.get_group(gid)
                        if group:
                            print(f"Участники группы '{group.name}':")
                            for addr in group.members:
                                contact = self.app.contact_manager.get_contact_by_addr(addr)
                                nick = contact.nick if contact else addr.split('@')[0]
                                print(f"  - {nick} ({addr})")
                        else:
                            print("Группа не найдена.")
                    else:
                        print("Использование: /group members <group_id>")
                elif cmd.startswith("/group sync "):
                    parts = cmd.split()
                    if len(parts) == 3:
                        gid = parts[2]
                        group = self.app.group_manager.get_group(gid)
                        if group:
                            await self.app.group_manager.request_group_sync(group, self.app)
                            print(f"Запрос синхронизации группы {group.name} отправлен создателю.")
                        else:
                            print("Группа не найдена.")
                    else:
                        print("Использование: /group sync <group_id>")
                elif cmd.startswith("/notify "):
                    arg = cmd.split()[1].lower()
                    if arg in ('on', 'off'):
                        self.app.notifications_enabled = (arg == 'on')
                        self.app._save_config()
                        print(f"Уведомления: {'включены' if self.app.notifications_enabled else 'выключены'}")
                    else:
                        print("Использование: /notify on|off")
                elif cmd.startswith("/log"):
                    parts = cmd.split()
                    n = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 20
                    self._show_log(n)
                else:
                    print("Неизвестная команда. Введите /help для списка команд.")
            except KeyboardInterrupt:
                self.app.running = False
                break
            except Exception as e:
                logger.error(f"UI error: {e}")

    def _show_help(self):
        print(f"{C_CYAN}=== Доступные команды ==={C_RESET}")
        print(f"  {C_YELLOW}/help{C_RESET}              - показать эту справку")
        print(f"  {C_YELLOW}/mykey{C_RESET}            - показать свой ключ и QR-URL")
        print(f"  {C_YELLOW}/add <url>|...{C_RESET}   - добавить контакт (URL или ручной ввод)")
        print(f"  {C_YELLOW}/send <idx> <text>{C_RESET} - отправить сообщение")
        print(f"  {C_YELLOW}/list{C_RESET}            - список контактов")
        print(f"  {C_YELLOW}/online{C_RESET}          - онлайн контакты")
        print(f"  {C_YELLOW}/del <idx>{C_RESET}       - удалить контакт")
        print(f"  {C_YELLOW}/newnick <nick>{C_RESET}  - сменить ник")
        print(f"  {C_YELLOW}/history [idx]{C_RESET}   - история (всех или контакта)")
        print(f"  {C_YELLOW}/read <idx>{C_RESET}      - отметить сообщения контакта прочитанными")
        print(f"  {C_YELLOW}/resend{C_RESET}          - принудительная отправка очереди")
        print(f"  {C_YELLOW}/rotate{C_RESET}          - принудительная ротация X25519 ключа (PFS)")
        print(f"  {C_YELLOW}/group create <name>{C_RESET} - создать группу")
        print(f"  {C_YELLOW}/group add <gid> <idx>{C_RESET} - добавить участника в группу")
        print(f"  {C_YELLOW}/group remove <gid> <idx>{C_RESET} - удалить участника из группы")
        print(f"  {C_YELLOW}/group rotatekey <gid>{C_RESET} - сменить ключ группы")
        print(f"  {C_YELLOW}/group send <gid> <text>{C_RESET} - отправить в группу")
        print(f"  {C_YELLOW}/group list{C_RESET}      - список групп")
        print(f"  {C_YELLOW}/group members <gid>{C_RESET} - список участников группы")
        print(f"  {C_YELLOW}/group sync <gid>{C_RESET}   - запросить синхронизацию группы")
        print(f"  {C_YELLOW}/notify on|off{C_RESET}   - управление уведомлениями")
        print(f"  {C_YELLOW}/log [N]{C_RESET}         - показать последние N строк лога")
        print(f"  {C_YELLOW}/exit{C_RESET}            - выход")

    def _show_contacts(self, only_online=False):
        contacts = self.app.contact_manager.contacts
        if not contacts:
            print("Нет контактов")
            return
        for i, c in enumerate(contacts):
            if only_online and not c.online:
                continue
            status = f"{C_GREEN}●{C_RESET}" if c.online else f"{C_RED}○{C_RESET}"
            print(f"{i}: {c.nick} ({c.addr}) {status}")

    def _show_mykey(self):
        url = self.app.generate_mykey_url()
        ed_pub_b64 = base64.b64encode(self.app.crypto.public_key_ed25519.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )).decode()
        x_pub_b64 = base64.b64encode(self.app.crypto.public_key_x25519.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )).decode()
        fingerprint = hashlib.sha256(base64.b64decode(ed_pub_b64)).hexdigest()[:8]

        print(f"\n{C_CYAN}=== Ваш ключ ==={C_RESET}")
        print(f"Ник:     {C_GREEN}{self.app.nick}{C_RESET}")
        print(f"Адрес:   {C_GREEN}{self.app.my_addr}{C_RESET}")
        print(f"Ed25519 Fingerprint: {C_YELLOW}{fingerprint}{C_RESET}")
        print(f"Ed25519 Pub: {C_GRAY}{ed_pub_b64[:40]}...{C_RESET}")
        print(f"X25519 Pub:  {C_GRAY}{x_pub_b64[:40]}...{C_RESET}")
        print(f"\n{C_CYAN}URL для обмена (QR-код):{C_RESET}")
        print(f"{C_GREEN}{url}{C_RESET}")

        if QRCODE_AVAILABLE:
            try:
                qr = qrcode.QRCode(border=1)
                qr.add_data(url)
                qr.make(fit=True)
                qr.print_ascii()
            except:
                pass
        print()

    async def _show_history(self, contact_idx: int = None, limit=20):
        history = self.app.message_store.get_history(limit)
        if contact_idx is not None:
            contact = self.app.contact_manager.contacts[contact_idx]
            history = [h for h in history if h['remote_addr'] == contact.addr]
            unread = self.app.message_store.get_unread_messages(contact.addr)
            for db_id, msg_id in unread:
                await self.app._send_read_receipt(contact.addr, msg_id)
                self.app.message_store.mark_read(db_id)
            if unread:
                print(f"{C_GREEN}Отправлены read receipt для {len(unread)} сообщений от {contact.nick}.{C_RESET}")
        else:
            unread_all = self.app.message_store.get_unread_messages_all()
            for db_id, msg_id, remote_addr in unread_all:
                await self.app._send_read_receipt(remote_addr, msg_id)
                self.app.message_store.mark_read(db_id)
            if unread_all:
                print(f"{C_GREEN}Отправлены read receipt для {len(unread_all)} непрочитанных сообщений.{C_RESET}")

        if not history:
            print("Нет сообщений")
            return

        for h in reversed(history):
            dir_symbol = "→" if h['direction'] == 'out' else ("◎" if h['direction'] == 'group' else "←")
            ts = datetime.fromtimestamp(h['timestamp']).strftime("%H:%M:%S")
            delivered = "✓" if h['delivered'] else "⏳"
            read_status = f"{C_GREEN}✓✓{C_RESET}" if h['read'] else delivered

            if h['direction'] == 'group':
                group = self.app.group_manager.get_group(h['remote_addr'])
                display_name = group.name if group else h['remote_addr']
                print(f"{ts} {dir_symbol} [Группа {display_name}] {h['text']} {read_status}")
            else:
                print(f"{ts} {dir_symbol} {h['text']} {read_status}")

    def _show_log(self, n: int = 20):
        log_file = LOG_DIR / "zerotracer.log"
        if not log_file.exists():
            print("Лог-файл не найден.")
            return
        try:
            with open(log_file, "r") as f:
                lines = f.readlines()
            for line in lines[-n:]:
                print(line.rstrip())
        except Exception as e:
            print(f"Ошибка чтения лога: {e}")

# ----------------------------------------------------------------------
# Запуск
# ----------------------------------------------------------------------
def check_dependencies():
    missing = []
    try:
        import cryptography
    except ImportError:
        missing.append("cryptography")
    try:
        import aiosocks
    except ImportError:
        missing.append("aiosocks (для Tor)")
    if missing:
        print(f"{C_RED}Отсутствуют зависимости: {', '.join(missing)}{C_RESET}")
        print("Установите их: pip install " + " ".join(missing))
        if "aio_socks" in missing and input("Продолжить без Tor? (y/N): ").strip().lower() != 'y':
            sys.exit(1)
        return False
    return True

async def main():
    print(BANNER)
    if not check_dependencies():
        print(f"{C_YELLOW}Некоторые зависимости отсутствуют, но работа продолжится с ограничениями.{C_RESET}")
    use_tor = False
    if input("Использовать Tor? (y/N): ").strip().lower() == 'y':
        if not AIO_SOCKS_AVAILABLE:
            print(f"{C_RED}Для Tor требуется aio_socks. Установите: pip install aio_socks{C_RESET}")
        else:
            use_tor = True
    app = ZeroTracerAsync(use_tor=use_tor)
    await app.start_servers()
    ui = ConsoleUI(app)
    try:
        await ui.run()
    finally:
        await app.stop()

if __name__ == "__main__":
    asyncio.run(main())