#!/usr/bin/env python3
# tests/test_zerotracer.py
# Модульные тесты для ZeroTracer

import os
import sys
import json
import asyncio
import sqlite3
import tempfile
import shutil
import hashlib
import base64
import secrets
import time
from pathlib import Path
from unittest.mock import patch, MagicMock, AsyncMock
import pytest
import pytest_asyncio

# Добавляем путь к исходному коду (если тесты запускаются из корня проекта)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ZeroTracer import (
    CryptoManager, ContactManager, GroupManager, MessageStore, Protocol,
    Contact, Group, Fragment, ZeroTracerAsync, LOG_DIR
)
from cryptography.hazmat.primitives.asymmetric import x25519, ed25519
from cryptography.hazmat.primitives import serialization

# ----------------------------------------------------------------------
# Фикстуры
# ----------------------------------------------------------------------

@pytest.fixture
def temp_dir():
    """Временная директория для данных."""
    with tempfile.TemporaryDirectory() as tmpdir:
        old_home = Path.home()
        with patch('pathlib.Path.home', return_value=Path(tmpdir)):
            yield Path(tmpdir)


@pytest.fixture
def crypto_manager(temp_dir):
    """CryptoManager с временной директорией и фиктивным паролем."""
    cm = CryptoManager(temp_dir)
    with patch('builtins.input', return_value='testpass'):
        success = cm.load_or_create_keys('testpass')
        assert success is True
    # Убеждаемся, что ключ шифрования БД установлен
    assert cm.db_encryption_key is not None
    return cm


@pytest.fixture
def db_conn():
    """In-memory база данных для тестов."""
    conn = sqlite3.connect(':memory:')
    return conn


@pytest.fixture
def contact_manager(crypto_manager, db_conn):
    """ContactManager с тестовой БД."""
    cm = ContactManager(crypto_manager, db_conn)
    return cm


@pytest.fixture
def group_manager(crypto_manager, db_conn):
    """GroupManager с тестовой БД."""
    gm = GroupManager(crypto_manager, db_conn)
    return gm


@pytest.fixture
def message_store(crypto_manager, db_conn):
    """MessageStore с тестовой БД и ключом шифрования."""
    # crypto_manager уже имеет db_encryption_key после загрузки
    ms = MessageStore(db_conn, crypto_manager)
    return ms


@pytest.fixture
def sample_contact():
    """Тестовый контакт."""
    ed_priv = ed25519.Ed25519PrivateKey.generate()
    ed_pub = ed_priv.public_key()
    x_priv = x25519.X25519PrivateKey.generate()
    x_pub = x_priv.public_key()
    ed_pub_b64 = base64.b64encode(ed_pub.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw
    )).decode()
    x_pub_b64 = base64.b64encode(x_pub.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw
    )).decode()
    return Contact(
        nick="alice",
        addr="alice@localhost:5555",
        pubkey=ed_pub_b64,
        x25519_pub=x_pub_b64,
        online=False,
        last_seen=0.0,
        shared_secret=None
    )


# ----------------------------------------------------------------------
# Тесты CryptoManager
# ----------------------------------------------------------------------
class TestCryptoManager:
    def test_generate_keys(self, crypto_manager):
        ed_pub, ed_priv, x_pub, x_priv = crypto_manager.generate_keys()
        assert isinstance(ed_pub, str)
        assert isinstance(ed_priv, str)
        assert isinstance(x_pub, str)
        assert isinstance(x_priv, str)
        assert len(ed_pub) == 44
        assert len(ed_priv) == 44
        assert len(x_pub) == 44
        assert len(x_priv) == 44

    def test_load_or_create_keys(self, temp_dir):
        """Тестирование создания и загрузки ключей."""
        crypto = CryptoManager(temp_dir)
        with patch('builtins.input', return_value='pass123'):
            success = crypto.load_or_create_keys('pass123')
        assert success is True
        assert crypto.private_key_ed25519 is not None
        assert crypto.public_key_ed25519 is not None
        assert crypto.private_key_x25519 is not None
        assert crypto.public_key_x25519 is not None
        # Повторная загрузка с тем же паролем
        crypto2 = CryptoManager(temp_dir)
        with patch('builtins.input', return_value='pass123'):
            success2 = crypto2.load_or_create_keys('pass123')
        assert success2 is True
        pub1 = crypto.public_key_ed25519.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        pub2 = crypto2.public_key_ed25519.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        assert pub1 == pub2

    def test_load_or_create_keys_wrong_password(self, temp_dir):
        crypto = CryptoManager(temp_dir)
        with patch('builtins.input', return_value='correct'):
            crypto.load_or_create_keys('correct')
        crypto2 = CryptoManager(temp_dir)
        with patch('builtins.input', return_value='wrong'):
            success = crypto2.load_or_create_keys('wrong')
        assert success is False

    def test_sign_and_verify(self, crypto_manager):
        data = b"test message"
        signature = crypto_manager.sign(data)
        pubkey_b64 = base64.b64encode(crypto_manager.public_key_ed25519.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )).decode()
        assert crypto_manager.verify(signature, data, pubkey_b64) is True
        assert crypto_manager.verify(signature, b"wrong", pubkey_b64) is False

    def test_compute_shared_secret(self, crypto_manager):
        peer_priv = x25519.X25519PrivateKey.generate()
        peer_pub = peer_priv.public_key()
        peer_pub_b64 = base64.b64encode(peer_pub.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )).decode()
        secret1 = crypto_manager.compute_shared_secret(peer_pub_b64)
        from cryptography.hazmat.primitives.kdf.hkdf import HKDF
        from cryptography.hazmat.primitives import hashes
        hkdf = HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=b"zerotracer-messaging")
        peer_secret = peer_priv.exchange(crypto_manager.public_key_x25519)
        peer_derived = hkdf.derive(peer_secret)
        assert secret1 == peer_derived

    def test_encrypt_decrypt_message(self, crypto_manager):
        shared_secret = os.urandom(32)
        plain = "Hello, World!"
        ciphertext_b64, nonce, tag = crypto_manager.encrypt_message(plain, shared_secret)
        decrypted = crypto_manager.decrypt_message(ciphertext_b64, nonce, tag, shared_secret)
        assert decrypted == plain

    def test_rotate_x25519_key(self, crypto_manager, temp_dir):
        old_pub = crypto_manager.public_key_x25519
        old_pub_b64 = base64.b64encode(old_pub.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )).decode()
        success = crypto_manager.rotate_x25519_key()
        assert success is True
        new_pub_b64 = base64.b64encode(crypto_manager.public_key_x25519.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )).decode()
        assert old_pub_b64 != new_pub_b64
        crypto2 = CryptoManager(temp_dir)
        with patch('builtins.input', return_value='testpass'):
            crypto2.load_or_create_keys('testpass')
        loaded_pub_b64 = base64.b64encode(crypto2.public_key_x25519.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )).decode()
        assert loaded_pub_b64 == new_pub_b64


# ----------------------------------------------------------------------
# Тесты ContactManager
# ----------------------------------------------------------------------
class TestContactManager:
    def test_add_and_get_contact(self, contact_manager, sample_contact):
        contact_manager.save_contact(sample_contact)
        retrieved = contact_manager.get_contact_by_addr(sample_contact.addr)
        assert retrieved is not None
        assert retrieved.nick == sample_contact.nick
        assert retrieved.addr == sample_contact.addr

    def test_delete_contact(self, contact_manager, sample_contact):
        contact_manager.save_contact(sample_contact)
        contact_manager.delete_contact(sample_contact.addr)
        assert contact_manager.get_contact_by_addr(sample_contact.addr) is None

    def test_compute_shared_secret(self, contact_manager, crypto_manager, sample_contact):
        contact_manager.save_contact(sample_contact)
        secret = contact_manager.compute_shared_secret(sample_contact)
        assert secret is not None
        secret2 = contact_manager.compute_shared_secret(sample_contact)
        assert secret == secret2

    def test_update_x25519_key(self, contact_manager, sample_contact):
        contact_manager.save_contact(sample_contact)
        new_x_pub = base64.b64encode(os.urandom(32)).decode()
        contact_manager.update_x25519_key(sample_contact.addr, new_x_pub)
        updated = contact_manager.get_contact_by_addr(sample_contact.addr)
        assert updated.x25519_pub == new_x_pub
        assert updated.shared_secret is None


# ----------------------------------------------------------------------
# Тесты GroupManager
# ----------------------------------------------------------------------
class TestGroupManager:
    def test_create_group(self, group_manager):
        group = group_manager.create_group("Test Group", "alice@localhost")
        assert group.group_id is not None
        assert group.name == "Test Group"
        assert group.creator == "alice@localhost"
        assert len(group.members) == 1
        assert "alice@localhost" in group.members
        loaded = group_manager.get_group(group.group_id)
        assert loaded is not None
        assert loaded.name == group.name

    def test_add_member(self, group_manager):
        group = group_manager.create_group("Group", "creator@a")
        assert group_manager.add_member(group.group_id, "member@b") is True
        group = group_manager.get_group(group.group_id)
        assert "member@b" in group.members
        assert group_manager.add_member(group.group_id, "member@b") is False

    def test_remove_member(self, group_manager):
        group = group_manager.create_group("Group", "creator@a")
        group_manager.add_member(group.group_id, "member@b")
        assert group_manager.remove_member(group.group_id, "member@b", "not_creator") is False
        assert group_manager.remove_member(group.group_id, "member@b", "creator@a") is True
        group = group_manager.get_group(group.group_id)
        assert "member@b" not in group.members

    def test_rotate_group_key(self, group_manager):
        group = group_manager.create_group("Group", "creator@a")
        old_key = group.symmetric_key
        new_key = group_manager.rotate_group_key(group.group_id, "creator@a")
        assert new_key is not None
        assert new_key != old_key
        group = group_manager.get_group(group.group_id)
        assert group.symmetric_key == new_key
        assert group_manager.rotate_group_key(group.group_id, "hacker") is None

    def test_nonce_used_in_group(self, group_manager):
        group_id = "g123"
        sender = "alice@a"
        nonce = "abc"
        assert group_manager.is_nonce_used_in_group(group_id, sender, nonce) is False
        group_manager.store_group_nonce(group_id, sender, nonce)
        assert group_manager.is_nonce_used_in_group(group_id, sender, nonce) is True
        assert group_manager.is_nonce_used_in_group(group_id, "bob@b", nonce) is False


# ----------------------------------------------------------------------
# Тесты MessageStore
# ----------------------------------------------------------------------
class TestMessageStore:
    def test_save_and_get_message(self, message_store):
        db_id, msg_hash = message_store.save_message(
            remote_addr="alice@localhost",
            direction="in",
            text="Hello",
            msg_id="msg123"
        )
        assert db_id > 0
        assert msg_hash is not None
        history = message_store.get_history(limit=10)
        assert len(history) == 1
        assert history[0]['text'] == "Hello"
        assert history[0]['direction'] == "in"
        assert history[0]['remote_addr'] == "alice@localhost"

    def test_mark_delivered_read(self, message_store):
        db_id, _ = message_store.save_message("addr", "out", "text", "mid")
        message_store.mark_delivered(db_id)
        message_store.mark_read(db_id)
        history = message_store.get_history(1)
        assert history[0]['delivered'] is True
        assert history[0]['read'] is True

    def test_queue_message(self, message_store):
        # Убедимся, что ключ шифрования есть (фикстура его уже установила)
        message_store.crypto.db_encryption_key = os.urandom(32)  # на всякий случай
        message_store.queue_message(
            target_addr="bob@b",
            plain_text="queued text",
            original_msg_id="mid123",
            msg_hash="hash123"
        )
        queued = message_store.get_queued_messages()
        assert len(queued) == 1
        qid, target, plain, msg_hash, orig_id, is_group, group_id = queued[0]
        assert target == "bob@b"
        assert plain == "queued text"
        assert orig_id == "mid123"
        message_store.delete_queued(qid)
        assert len(message_store.get_queued_messages()) == 0

    def test_fragments(self, message_store):
        frag = Fragment(
            msg_id="frag1", from_addr="alice@a", part_num=1, total_parts=2,
            data="part1", timestamp=time.time()
        )
        message_store.save_fragment(frag)
        frag2 = Fragment(
            msg_id="frag1", from_addr="alice@a", part_num=2, total_parts=2,
            data="part2", timestamp=time.time()
        )
        message_store.save_fragment(frag2)
        fragments = message_store.get_fragments("frag1", "alice@a")
        assert len(fragments) == 2
        message_store.delete_fragments("frag1", "alice@a")
        assert len(message_store.get_fragments("frag1", "alice@a")) == 0

    def test_fragment_mask(self, message_store):
        msg_id = "mask_test"
        from_addr = "alice"
        total = 5
        missing = message_store.get_missing_parts(msg_id, from_addr, total)
        assert missing == [1,2,3,4,5]
        mask = message_store.update_fragment_mask(msg_id, from_addr, total, 1)
        assert mask & 1 == 1
        missing = message_store.get_missing_parts(msg_id, from_addr, total)
        assert missing == [2,3,4,5]
        message_store.update_fragment_mask(msg_id, from_addr, total, 3)
        missing = message_store.get_missing_parts(msg_id, from_addr, total)
        assert missing == [2,4,5]
        message_store.clear_fragment_mask(msg_id, from_addr)
        missing = message_store.get_missing_parts(msg_id, from_addr, total)
        assert missing == [1,2,3,4,5]

    def test_nonce_used(self, message_store):
        nonce = "test_nonce"
        assert message_store.is_nonce_used(nonce) is False
        message_store.store_nonce(nonce)
        assert message_store.is_nonce_used(nonce) is True

    def test_cleanup_old_messages(self, message_store):
        conn = message_store.db_conn
        cursor = conn.cursor()
        old_time = time.time() - 31 * 86400
        cursor.execute('''
            INSERT INTO messages (remote_addr, direction, text_enc, text_nonce, timestamp, msg_hash, msg_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', ('addr', 'in', b'', b'', old_time, 'oldhash', 'oldid'))
        conn.commit()
        message_store.cleanup_old_messages(days=30)
        cursor.execute('SELECT COUNT(*) FROM messages WHERE msg_id="oldid"')
        count = cursor.fetchone()[0]
        assert count == 0


# ----------------------------------------------------------------------
# Тесты Protocol
# ----------------------------------------------------------------------
class TestProtocol:
    def test_build_and_parse_packet(self):
        payload = {"foo": "bar"}
        packet = Protocol.build_packet("ping", "from@a", "to@b", payload)
        parsed = Protocol.parse_packet(packet)
        assert parsed is not None
        assert parsed["type"] == "ping"
        assert parsed["from"] == "from@a"
        assert parsed["to"] == "to@b"
        assert parsed["payload"]["foo"] == "bar"
        assert parsed["version"] == Protocol.VERSION

    def test_parse_invalid(self):
        assert Protocol.parse_packet("not json") is None


# ----------------------------------------------------------------------
# Интеграционные тесты для ZeroTracerAsync (ограниченные, без реальных серверов)
# ----------------------------------------------------------------------
@pytest_asyncio.fixture
async def app_instance(temp_dir):
    """Создаёт экземпляр приложения с моками ввода и без реальных серверов."""
    with patch('builtins.input', side_effect=['testpass', '5555']):
        app = ZeroTracerAsync(use_tor=False)
        # Подменяем start_servers на заглушку, чтобы не занимать реальные порты
        app.start_servers = AsyncMock()
        app._send_raw = AsyncMock(return_value=True)
        await app.start_servers()  # ничего не делает
        yield app
        await app.stop()


@pytest.mark.asyncio
async def test_send_message(app_instance, contact_manager, sample_contact):
    contact_manager.save_contact(sample_contact)
    shared_secret = os.urandom(32)
    with patch.object(contact_manager, 'compute_shared_secret', return_value=shared_secret):
        await app_instance.send_message(sample_contact, "Test message")
        app_instance._send_raw.assert_called_once()
        history = app_instance.message_store.get_history(10)
        assert len(history) == 1
        assert history[0]['text'] == "Test message"
        assert history[0]['direction'] == "out"


@pytest.mark.asyncio
async def test_handle_message(app_instance, contact_manager, crypto_manager, sample_contact):
    contact_manager.save_contact(sample_contact)
    shared_secret = crypto_manager.compute_shared_secret(sample_contact.x25519_pub)
    msg_id = secrets.token_hex(16)
    plain = "Hello from test"
    ciphertext_b64, nonce, tag = crypto_manager.encrypt_message(plain, shared_secret)
    nonce_b64 = base64.b64encode(nonce).decode()
    tag_b64 = base64.b64encode(tag).decode()
    sign_data = f"{msg_id}{nonce_b64}{ciphertext_b64}".encode()
    signature = crypto_manager.sign(sign_data)
    signature_b64 = base64.b64encode(signature).decode()
    payload = {
        "msg_id": msg_id,
        "signature": signature_b64,
        "nonce": nonce_b64,
        "tag": tag_b64,
        "ciphertext": ciphertext_b64
    }
    packet = Protocol.build_packet("message", sample_contact.addr, app_instance.my_addr, payload)
    # Создаём полноценный мок writer с необходимыми методами
    writer_mock = AsyncMock()
    writer_mock.write = AsyncMock()
    writer_mock.drain = AsyncMock()
    writer_mock.close = MagicMock()
    writer_mock.wait_closed = AsyncMock()
    await app_instance._process_packet(Protocol.parse_packet(packet), writer_mock)
    history = app_instance.message_store.get_history(10)
    assert len(history) == 1
    assert history[0]['text'] == plain
    assert history[0]['direction'] == "in"
    assert history[0]['read'] is True


@pytest.mark.asyncio
async def test_group_message(app_instance, group_manager, contact_manager, crypto_manager):
    group = group_manager.create_group("TestGroup", app_instance.my_addr)
    fake_contact = Contact(nick="bob", addr="bob@b", pubkey="", x25519_pub="")
    contact_manager.save_contact(fake_contact)
    group_manager.add_member(group.group_id, fake_contact.addr)
    app_instance._send_raw = AsyncMock(return_value=True)
    await app_instance.send_group_message(group, "Group text")
    app_instance._send_raw.assert_called_once()
    history = app_instance.message_store.get_history(10)
    assert len(history) == 1
    assert history[0]['text'] == "Group text"
    assert history[0]['direction'] == "group"


# ----------------------------------------------------------------------
# Запуск тестов
if __name__ == "__main__":
    pytest.main(["-v", __file__])